#Include 'Protheus.ch'
#Include 'Parmtype.ch'
#Include 'TOTVS.ch'

/***********************************************************************
Autor: Pedro Vilas Boas / Vinicius N. de Oliveira
Data: 12/2024
Consultoria: Proativa
Uso: Calibre
Tipo: Atualiza��es
Rotina: Estoque/Custos
Fun��o: xCavEtq1
Info: Impress�o de Etiqueta Quimica.
************************************************************************/
User Function xCavEtq1()

	Local aArea       := GetArea()
	Local _cPathFile  := "c:/etiquetas/"
	Local aPergs      := {}

	Private _cDir     := ""
	Private cNomePC   := ComputerName()

	//Private cModZM400 := GetMV("XX_ZM400",.F.,"CARS0038")

	//Diretorio Raiz
	_cDir := _cPathFile 

	If !ExistDir(_cDir)
		MakeDir(_cDir)
	Endif

	DbSelectArea("ZZI")

	IF !PergParam(@aPergs)
		Return
	Endif

	sfEtiqueta(aPergs)

	RestArea(aArea)

Return

/*=================================================================
Autor: Pedro Vilas Boas / Vinicius N. de Oliveira
Data: 13/03/2025
Consultoria: Proativa
Uso: Calibre
Info: Grava os arquivos com as strings das etiquetas
*==================================================================*/
Static Function sfEtiqueta(aPergs)

	Local cModelo	:= "ZEBRA" 
	Local cPorta	:= "LPT1"
	Local cStrEtiq  := ""

	Private aArqGerados := {}

	cStrEtiq := sfStrEtiq(aPergs,cModelo,cPorta)

	If !Empty(cStrEtiq)
		GeraArqEtq(cStrEtiq)
	Endif

Return

/*=================================================================
Autor: Pedro Vilas Boas / Vinicius N. de Oliveira
Data: 13/03/2025
Consultoria: Proativa
Uso: Calibre
Info: Gera a string com a etiqueta a ser enviada para a impressora 
Zebra. A string cont�m c�digo ZPL
*==================================================================*/
Static Function sfStrEtiq(aPergs,cModelo,cPorta)

	Local cRet       := ""
	Local aFrasesP   := {}
	Local cFrasesP   := ""
	Local aFrasesH   := {}
	Local cFrasesH   := ""
	Local aPictos    := {}
	Local aPictosZB4 := {}
	Local nX         := 0
	Local VarControl := ""
	Local cDtValid   := ""
	//Local lZM400     := .F.

	SB1->(DbSetOrder(1))
	
	If !SB1->(DbSeek(xFilial("SB1")+aPergs[1]))
		Alert("Produto n�o encontrado")
		Return(cRet)
	Endif

	SB8->(DbSetOrder(5))
	
	If !SB8->(DbSeek(xFilial("SB8")+aPergs[1]+aPergs[2]))
	
		If !ExistLote(aPergs[2])
			Alert("ATENCAO: Este lote de produto nao existe!")
		Else
			Alert("ATENCAO: Este lote nao pertence a este produto!")
		Endif
		
		Return(cRet)
		
	Endif

	cDtValid := DTOC(SB8->B8_DTVALID)

	SB5->(DbSetOrder(1))

	cTextoH1 := "Importador/Fornecedor: Calibre Scientific Brasil LTDA. CNPJ: 01.530.501/0001-42 - Av. Pres. Get�lio Vargas, 8806, Dist. Industrial, Alvorada, RS | Tel: (11) 4812-5061" 
	cTextoH2 := "Telefone para emerg�ncias qu�micas 24h: ABIQUIM / Pr�-Qu�mica�: 0800-110-8270" 

	cTextoR1 := "Respons�vel t�cnico: Willian Vagner Salla CRQ/RS 051002184 | R�tulo NBR 14725:2024 ver.241202 |"

	If SB1->B1_CRVPF = 'S' .AND. SB1->B1_CRVME = 'S'
		VarControl := "PRODUTO CONTROLADO PELA POL�CIA FEDERAL E PELO EX�RCITO"
	Elseif SB1->B1_CRVPF = 'S'
		VarControl := "PRODUTO CONTROLADO PELA POL�CIA FEDERAL"
	Elseif SB1->B1_CRVME = 'S'
		VarControl := "PRODUTO CONTROLADO PELO EX�RCITO"
	Endif

	ZZI->(DbSetOrder(1))
	
	aFrasesP := Separa(AllTrim(SB1->B1_XFRASEP)," ")
	
	For nX := 1 to Len(aFrasesP)
	
		If ZZI->(DbSeek(xFilial("ZZI")+aFrasesP[nX]))
			cFrasesP += AllTrim(ZZI->ZZI_COD)+" - "+AllTrim((ZZI->ZZI_TEXTO)+";  ")
		Endif
		
	Next nX

	aFrasesH := Separa(AllTrim(SB1->B1_XFRASEH)," ")
	
	For nX := 1 to Len(aFrasesH)
	
		If ZZI->(DbSeek(xFilial("ZZI")+aFrasesH[nX]))
			cFrasesH += AllTrim(ZZI->ZZI_COD)+" - "+AllTrim((ZZI->ZZI_TEXTO)+";  ")
		Endif
		
	Next nX

	aPictos := Separa(AllTrim(SB1->B1_XPICTOG)," ")

	//MsgAlert(cNomePC)
	
	//Identifico se a impressora Zebra � a ZM400 para seguir com o layout da etiqueta

	//If (cNomePC) $ cModZM400
	//	lZM400 := .T.
	//Endif

	// ---

	//Identifica��o dos pictogramas que constam no cadastro de produto para que possam ser apresentados na etiqueta
	//If lZM400

		For nX := 1 To Len(aPictos)
		
			If ZZI->(DbSeek(xFilial("ZZI")+aPictos[nX]))
				aAdd(aPictosZB4,{aPictos[nX],AllTrim(ZZI->ZZI_TEXTO)})
			Endif
			
		Next nX
		/*
	Else 

		For nX := 1 To Len(aPictos)
		
			If ZZI->(DbSeek(xFilial("ZZI")+aPictos[nX]+"2"))
				aAdd(aPictosZB4,{aPictos[nX],AllTrim(ZZI->ZZI_TEXTO)})
			Endif
			
		Next nX

	Endif            */
	// ---

	//Cria��o da string das etiquetas
	//If lZM400

				//Modelo para impressoras ZM400
		//cRet += "^XA~TA000~JSN^LT0^MNW^MTT^PON^PMN^LH0,0^JMA^PR2,2~SD15^JUS^LRN^CI0^XZ" + CRLF
		cRet += "^XA" + CRLF
		cRet += "^MMT" + CRLF
		cRet += "^PW1314" + CRLF
		cRet += "^LL2041" + CRLF
		cRet += "^LS0" + CRLF

		cRet += "^FO32,15^GB370,1256,4^FS" + CRLF
		cRet += "^FO104,15^GB0,1256,4^FS" + CRLF
		cRet += "^FO372,15^GB0,1256,4^FS" + CRLF
		cRet += "^FO104,758^GB265,0,4^FS" + CRLF

		cRet += "^FT56,1254^A0B,17,16^FH\^FD"+cTextoH1+"^FS" + CRLF
		cRet += "^FT82,1254^A0B,17,16^FH\^FD"+cTextoH2+"^FS" + CRLF
		cRet += "^FT130,1254^A0B,17,17^FH\^FDC�digo: B1_COD^FS" + CRLF
		cRet += "^FT154,1254^A0B,17,17^FH\^FDDescricao: B1_DESC^FS" + CRLF
		cRet += "^FT253,1254^A0B,17,17^FH\^FDPalavra de advert�ncia: B1_XADVERT^FS" + CRLF
		cRet += "^FT277,1254^A0B,4,13^FH\^FDFrases de Perigo: FRASE_PERIGO^FS" + CRLF
		cRet += "^FT134,748^A0B,17,17^FH\^FDPictogramas:^FS" + CRLF
		cRet += "^FT180,1254^A0B,17,17^FH\^FDLote: PROD_LOTE^FS" + CRLF
		cRet += "^FT176,962^A0B,17,17^FH\^FDValidade: LOTE_VALID^FS" + CRLF
		cRet += "^FT301,748^A0B,4,13^FH\^FDFRASE_1_PRECAUCAO^FS" + CRLF

		IF Len(aPictosZB4) > 0
			cRet += "^FO128,606^GFA,02048,02048,00016,:Z64:"+aPictosZB4[1][2] + CRLF
		ELSE
			cRet += "^FO120,534^GB90,90,2^FS" + CRLF
		ENDIF

		IF Len(aPictosZB4) > 1
			cRet += "^FO128,493^GFA,02048,02048,00016,:Z64:"+aPictosZB4[2][2] + CRLF
		ELSE
			cRet += "^FO120,445^GB90,90,2^FS" + CRLF
		ENDIF

		IF Len(aPictosZB4) > 2
			cRet += "^FO128,380^GFA,02048,02048,00016,:Z64:"+aPictosZB4[3][2] + CRLF
		ELSE
			cRet += "^FO120,356^GB90,90,2^FS" + CRLF
		ENDIF

		IF Len(aPictosZB4) > 3
			cRet += "^FO128,267^GFA,02048,02048,00016,:Z64:"+aPictosZB4[4][2] + CRLF
		ELSE
			cRet += "^FO120,268^GB90,90,2^FS" + CRLF
		ENDIF

		IF Len(aPictosZB4) > 4
			cRet += "^FO128,154^GFA,02048,02048,00016,:Z64:"+aPictosZB4[5][2] + CRLF
		ELSE
			cRet += "^FO120,173^GB90,90,2^FS" + CRLF
		ENDIF

		IF Len(aPictosZB4) > 5
			cRet += "^FO128,42^GFA,02048,02048,00016,:Z64:"+aPictosZB4[6][2] + CRLF
		ELSE
			cRet += "^FO120,88^GB90,90,2^FS" + CRLF
		ENDIF

		cRet += "^FT393,1254^A0B,17,16^FH\^FD"+cTextoR1+" "+VarControl+"^FS" + CRLF
		cRet += "^FT204,1254^A0B,17,17^FH\^FDIdentidade Qu�mica: B1_XNOMONU^FS" + CRLF
		cRet += "^FT229,1254^A0B,17,17^FH\^FDCONTINUACAO_XOBS^FS" + CRLF
		cRet += "^FT301,1254^A0B,4,13^FH\^FDFRASE_1_PERIGO^FS" + CRLF
		cRet += "^FT326,1254^A0B,4,13^FH\^FDFRASE_2_PERIGO^FS" + CRLF
		cRet += "^FT349,1254^A0B,4,13^FH\^FDFRASE_3_PERIGO^FS" + CRLF
		cRet += "^FT326,748^A0B,4,13^FH\^FDFRASE_2_PRECAUCAO^FS" + CRLF
		cRet += "^FT349,748^A0B,4,13^FH\^FDFRASE_3_PRECAUCAO^FS" + CRLF

		cRet += "^FT277,748^A0B,4,13^FH\^FDFrases de Precau��o: FRASE_PRECAUCAO^FS" + CRLF

		cRet += "^FO440,15^GB370,1256,4^FS" + CRLF
		cRet += "^FO512,15^GB0,1256,4^FS" + CRLF
		cRet += "^FO779,15^GB0,1256,4^FS" + CRLF
		cRet += "^FO513,758^GB265,0,4^FS" + CRLF

		cRet += "^FT463,1254^A0B,17,16^FH\^FD"+cTextoH1+"^FS" + CRLF
		cRet += "^FT492,1254^A0B,17,16^FH\^FD"+cTextoH2+"^FS" + CRLF
		cRet += "^FT540,1254^A0B,17,17^FH\^FDC�digo: B1_COD^FS" + CRLF
		cRet += "^FT563,1254^A0B,17,17^FH\^FDDescricao: B1_DESC^FS" + CRLF
		cRet += "^FT660,1254^A0B,17,17^FH\^FDPalavra de advert�ncia: B1_XADVERT^FS" + CRLF
		cRet += "^FT685,1254^A0B,4,13^FH\^FDFrases de Perigo: FRASE_PERIGO^FS" + CRLF
		cRet += "^FT541,748^A0B,17,17^FH\^FDPictogramas:^FS" + CRLF
		cRet += "^FT587,1254^A0B,17,17^FH\^FDLote: PROD_LOTE^FS" + CRLF
		cRet += "^FT583,962^A0B,17,17^FH\^FDValidade: LOTE_VALID^FS" + CRLF
		cRet += "^FT709,748^A0B,4,13^FH\^FDFRASE_1_PRECAUCAO^FS" + CRLF

		IF Len(aPictosZB4) > 0
			cRet += "^FO537,606^GFA,02048,02048,00016,:Z64:"+aPictosZB4[1][2] + CRLF
		ELSE
			cRet += "^FO527,534^GB90,90,2^FS" + CRLF
		ENDIF

		IF Len(aPictosZB4) > 1
			cRet += "^FO537,493^GFA,02048,02048,00016,:Z64:"+aPictosZB4[2][2] + CRLF
		ELSE
			cRet += "^FO527,445^GB90,90,2^FS" + CRLF
		ENDIF

		IF Len(aPictosZB4) > 2
			cRet += "^FO537,380^GFA,02048,02048,00016,:Z64:"+aPictosZB4[3][2] + CRLF
		ELSE
			cRet += "^FO527,356^GB90,90,2^FS" + CRLF
		ENDIF

		IF Len(aPictosZB4) > 3
			cRet += "^FO537,267^GFA,02048,02048,00016,:Z64:"+aPictosZB4[4][2] + CRLF
		ELSE
			cRet += "^FO527,268^GB90,90,2^FS" + CRLF
		ENDIF

		IF Len(aPictosZB4) > 4
			cRet += "^FO537,154^GFA,02048,02048,00016,:Z64:"+aPictosZB4[5][2] + CRLF
		ELSE
			cRet += "^FO527,173^GB90,90,2^FS" + CRLF
		ENDIF

		IF Len(aPictosZB4) > 5
			cRet += "^FO537,42^GFA,02048,02048,00016,:Z64:"+aPictosZB4[6][2] + CRLF
		ELSE
			cRet += "^FO527,88^GB90,90,2^FS" + CRLF
		ENDIF

		cRet += "^FT800,1254^A0B,17,16^FH\^FD"+cTextoR1+" "+VarControl+"^FS" + CRLF
		cRet += "^FT614,1254^A0B,17,17^FH\^FDIdentidade Qu�mica: B1_XNOMONU^FS" + CRLF
		cRet += "^FT639,1254^A0B,17,17^FH\^FDCONTINUACAO_XOBS^FS" + CRLF
		cRet += "^FT709,1254^A0B,4,13^FH\^FDFRASE_1_PERIGO^FS" + CRLF
		cRet += "^FT732,1254^A0B,4,13^FH\^FDFRASE_2_PERIGO^FS" + CRLF
		cRet += "^FT757,1254^A0B,4,13^FH\^FDFRASE_3_PERIGO^FS" + CRLF
		cRet += "^FT733,748^A0B,4,13^FH\^FDFRASE_2_PRECAUCAO^FS" + CRLF
		cRet += "^FT757,748^A0B,4,13^FH\^FDFRASE_3_PRECAUCAO^FS" + CRLF
		cRet += "^FT685,748^A0B,4,13^FH\^FDFrases de Precau��o: FRASE_PRECAUCAO^FS" + CRLF

		cRet += "^PQ1,0,1,Y^XZ" + CRLF
		// ---

	/*Else 

		//Modelo para impressoras ZT230 e ZT410
		cRet := ""
		cRet += "^XA"+CRLF
		cRet += "^MMT"+CRLF
		cRet += "^PW820"+CRLF
		cRet += "^LL1279"+CRLF
		cRet += "^LS0"+CRLF
		cRet += "^FO35,30^GB350,1231,2^FS"+CRLF
		cRet += "^FO98,30^GB2,1231,2^FS"+CRLF
		cRet += "^FO100,647^GB238,2,2^FS"+CRLF
		cRet += "^FO337,30^GB2,1231,2^FS"+CRLF
		cRet += "^FT55,1250^A0B,15,20^FH\^FDImportador/Fornecedor: Calibre Scientific Brasil LTDA. CNPJ: 01.530.501/0001-42 - Av. Pres. Get\A3lio Vargas, 8806, Dist. Industrial, Alvorada, RS^FS"+CRLF
		cRet += "^FT90,1250^A0B,15,20^FH\^FD| Tel: (11) 4812-5061 | Telefone para emerg\88ncias qu\A1micas 24h: ABIQUIM / Pr\A2-Qu\A1mica\A9: 0800-110-8270^FS"+CRLF
		cRet += "^FT125,1250^A@B,16,5,TT0003M_^FH\^FDC\A2digo: B1_COD^FS"+CRLF
		cRet += "^FT145,1250^A@B,16,5,TT0003M_^FH\^FDDescricao: B1_DESC^FS"+CRLF
		cRet += "^FT240,1250^A@B,16,5,TT0003M_^FH\^FDPalavra de advert\88ncia: B1_XADVERT^FS"+CRLF 
		cRet += "^FT260,1250^A@B,16,5,TT0003M_^FH\^FDFrases de Perigo: FRASE_PERIGO^FS"+CRLF
		cRet += "^FT180,640^A@B,16,5,TT0003M_^FH\^FDPictogramas:^FS"+CRLF
		cRet += "^FT165,1250^A@B,16,5,TT0003M_^FH\^FDLote: PROD_LOTE^FS"+CRLF 
		cRet += "^FT165,950^A@B,16,5,TT0003M_^FH\^FDValidade: LOTE_VALID^FS"+CRLF
		cRet += "^FT260,640^A@B,16,5,TT0003M_^FH\^FDFRASE_1_PRECAUCAO^FS"+CRLF
		cRet += "^FT370,1250^A0B,15,18^FH\^FD"+cTextoR1+" "+VarControl+"^FS"+CRLF 
		cRet += "^FT185,1250^A@B,16,5,TT0003M_^FH\^FDIdentidade Qu\A1mica: B1_XNOMONU^FS"+CRLF
		cRet += "^FT202,1250^A@B,16,5,TT0003M_^FH\^FDCONTINUACAO_XOBS^FS"+CRLF
		cRet += "^FT285,1250^A@B,16,5,TT0003M_^FH\^FDFRASE_1_PERIGO^FS"+CRLF 
		cRet += "^FT305,1250^A@B,16,5,TT0003M_^FH\^FDFRASE_2_PERIGO^FS"+CRLF 
		cRet += "^FT325,1250^A@B,16,5,TT0003M_^FH\^FDFRASE_3_PERIGO^FS"+CRLF
		cRet += "^FT280,640^A@B,16,5,TT0003M_^FH\^FDFRASE_2_PRECAUCAO^FS"+CRLF
		cRet += "^FT300,640^A@B,16,5,TT0003M_^FH\^FDFRASE_3_PRECAUCAO^FS"+CRLF 
		cRet += "^FT240,640^A@B,16,5,TT0003M_^FH\^FDFrases de Precau\87\C6o: FRASE_PRECAUCAO^FS"+CRLF

		//Pictogramas Etiqueta 1
		If Len(aPictosZB4) > 0
			cRet += "^FO108,430^GFA,01536,01536,00012,:Z64:"+aPictosZB4[1][2]+CRLF
		Else
			cRet += "^FO129,420^GB69,69,2^FS" + CRLF //BOX 1
		Endif

		If Len(aPictosZB4) > 1
			cRet += "^FO108,353^GFA,01536,01536,00012,:Z64:"+aPictosZB4[2][2]+CRLF
		Else
			cRet += "^FO129,347^GB69,69,2^FS" + CRLF //BOX 2
		Endif

		If Len(aPictosZB4) > 2
			cRet += "^FO108,274^GFA,01536,01536,00012,:Z64:"+aPictosZB4[3][2]+CRLF
		Else
			cRet += "^FO129,274^GB69,69,2^FS" + CRLF //BOX 3
		Endif

		If Len(aPictosZB4) > 3
			cRet += "^FO108,195^GFA,01536,01536,00012,:Z64:"+aPictosZB4[4][2]+CRLF
		Else
			cRet += "^FO129,200^GB69,69,2^FS" + CRLF //BOX 4
		Endif

		If Len(aPictosZB4) > 4
			cRet += "^FO108,116^GFA,01536,01536,00012,:Z64:"+aPictosZB4[5][2]+CRLF
		Else
			cRet += "^FO129,127^GB69,69,2^FS" + CRLF //BOX 5
		Endif

		If Len(aPictosZB4) > 5
			cRet += "^FO108,38^GFA,01536,01536,00012,:Z64:"+aPictosZB4[6][2]+CRLF
		Else
			cRet += "^FO129,54^GB69,69,2^FS" + CRLF //BOX 6
		Endif

		cRet += "^FO470,30^GB350,1231,2^FS"+CRLF
		cRet += "^FO533,30^GB2,1231,2^FS"+CRLF
		cRet += "^FO535,647^GB238,2,2^FS"+CRLF
		cRet += "^FO772,30^GB2,1231,2^FS"+CRLF
		cRet += "^FT490,1250^A0B,15,20^FH\^FDImportador/Fornecedor: Calibre Scientific Brasil LTDA. CNPJ: 01.530.501/0001-42 - Av. Pres. Get\A3lio Vargas, 8806, Dist. Industrial, Alvorada, RS^FS"+CRLF 
		cRet += "^FT525,1250^A0B,15,20^FH\^FD| Tel: (11) 4812-5061 | Telefone para emerg\88ncias qu\A1micas 24h: ABIQUIM / Pr\A2-Qu\A1mica\A9: 0800-110-8270^FS"+CRLF 
		cRet += "^FT560,1250^A@B,16,5,TT0003M_^FH\^FDC\A2digo: B1_COD^FS"+CRLF
		cRet += "^FT585,1250^A@B,16,5,TT0003M_^FH\^FDDescricao: B1_DESC^FS"+CRLF
		cRet += "^FT680,1250^A@B,16,5,TT0003M_^FH\^FDPalavra de advert\88ncia: B1_XADVERT^FS"+CRLF 
		cRet += "^FT700,1250^A@B,16,5,TT0003M_^FH\^FDFrases de Perigo: FRASE_PERIGO^FS"+CRLF
		cRet += "^FT620,640^A@B,16,5,TT0003M_^FH\^FDPictogramas:^FS"+CRLF
		cRet += "^FT605,1250^A@B,16,5,TT0003M_^FH\^FDLote: PROD_LOTE^FS"+CRLF 
		cRet += "^FT605,950^A@B,16,5,TT0003M_^FH\^FDValidade: LOTE_VALID^FS"+CRLF
		cRet += "^FT700,640^A@B,16,5,TT0003M_^FH\^FDFRASE_1_PRECAUCAO^FS"+CRLF 
		cRet += "^FT810,1250^A0B,15,18^FH\^FD"+cTextoR1+" "+VarControl+"^FS"+CRLF
		cRet += "^FT625,1250^A@B,16,5,TT0003M_^FH\^FDIdentidade Qu\A1mica: B1_XNOMONU^FS"+CRLF
		cRet += "^FT642,1250^A@B,16,5,TT0003M_^FH\^FDCONTINUACAO_XOBS^FS"+CRLF 
		cRet += "^FT725,1250^A@B,16,5,TT0003M_^FH\^FDFRASE_1_PERIGO^FS"+CRLF
		cRet += "^FT745,1250^A@B,16,5,TT0003M_^FH\^FDFRASE_2_PERIGO^FS"+CRLF 
		cRet += "^FT765,1250^A@B,16,5,TT0003M_^FH\^FDFRASE_3_PERIGO^FS"+CRLF
		cRet += "^FT720,640^A@B,16,5,TT0003M_^FH\^FDFRASE_2_PRECAUCAO^FS"+CRLF 
		cRet += "^FT740,640^A@B,16,5,TT0003M_^FH\^FDFRASE_3_PRECAUCAO^FS"+CRLF 

		//Pictogramas Etiqueta 2
		If Len(aPictosZB4) > 0
			cRet += "^FO547,430^GFA,01536,01536,00012,:Z64:"+aPictosZB4[1][2]+CRLF
		Else
			cRet += "^FO564,420^GB69,69,2^FS" + CRLF //BOX 1
		Endif

		If Len(aPictosZB4) > 1
			cRet += "^FO547,353^GFA,01536,01536,00012,:Z64:"+aPictosZB4[2][2]+CRLF
		Else
			cRet += "^FO564,347^GB69,69,2^FS" + CRLF //BOX 2
		Endif

		If Len(aPictosZB4) > 2
			cRet += "^FO547,274^GFA,01536,01536,00012,:Z64:"+aPictosZB4[3][2]+CRLF
		Else
			cRet += "^FO564,274^GB69,69,2^FS" + CRLF //BOX 3
		Endif

		If Len(aPictosZB4) > 3
			cRet += "^FO547,195^GFA,01536,01536,00012,:Z64:"+aPictosZB4[4][2]+CRLF
		Else
			cRet += "^FO564,200^GB69,69,2^FS" + CRLF //BOX 4
		Endif

		If Len(aPictosZB4) > 4
			cRet += "^FO547,116^GFA,01536,01536,00012,:Z64:"+aPictosZB4[5][2]+CRLF
		Else
			cRet += "^FO564,127^GB69,69,2^FS" + CRLF //BOX 5
		Endif

		If Len(aPictosZB4) > 5
			cRet += "^FO547,38^GFA,01536,01536,00012,:Z64:"+aPictosZB4[6][2]+CRLF
		Else
			cRet += "^FO564,54^GB69,69,2^FS" + CRLF //BOX 6
		Endif

		cRet += "^FT680,640^A@B,16,5,TT0003M_^FH\^FDFrases de Precau\87\C6o: FRASE_PRECAUCAO^FS"+CRLF 
		cRet += "^PQ1,0,1,Y^XZ"+CRLF   

	Endif 							*/
	// ---

	//Substitui��o do C�digo e da Descri��o do produto na etiqueta
	cRet := StrTran(cRet,"B1_COD",AllTrim(SB1->B1_COD))
	cRet := StrTran(cRet,"B1_DESC",AllTrim(SubStr(SB1->B1_DESC,1,40)))
	// ---

	//Substitui��o da continua��o da descri��o na etiqueta [N�o est� em uso verificar necessidade]
	If Len(AllTrim(SB1->B1_DESC)) > 40
		cRet := StrTran(cRet,"DESC_CONTINUACAO",AllTrim(SubStr(SB1->B1_DESC,41,40)))
	Else
		cRet := StrTran(cRet,"DESC_CONTINUACAO","")
	Endif
	// ---

	//Substitui��o dos dados do lote e da advert�ncia na etiqueta
	cRet := StrTran(cRet,"PROD_LOTE",aPergs[2])
	cRet := StrTran(cRet,"LOTE_VALID",cDtValid)
	cRet := StrTran(cRet,"B1_XADVERT",IIf(AllTrim(SB1->B1_XADVERT) == "1","",IIf(AllTrim(SB1->B1_XADVERT) == "2","PERIGO","ATEN��O"))) 
	// ---                                                                                           

	//Substitui��o das frases de Observa��o da etiqueta
	If !Empty(SB1->B1_XNOMONU)
	
		cRet := StrTran(cRet,"B1_XNOMONU",AllTrim(SubStr(SB1->B1_XNOMONU,1,38)))
			
		If Len(AllTrim(SB1->B1_XNOMONU)) > 38
			cRet := StrTran(cRet,"CONTINUACAO_XOBS","-"+AllTrim(SubStr(SB1->B1_XNOMONU,39,90)))
		Else
			cRet := StrTran(cRet,"CONTINUACAO_XOBS","")
		Endif
		
	Else
		cRet := StrTran(cRet,"B1_XNOMONU","")
		cRet := StrTran(cRet,"CONTINUACAO_XOBS","")
	Endif
	// ---

	//Substitui��o de caracteres das frases de Perigo e Precau��o da etiqueta
	// If lZM400 //Tratativa para impressora ZM400

		For nX := 1 To 2

			If nX == 1 
				cRet := StrTran(cRet,"FRASE_PERIGO",AllTrim(SubStr(cFrasesH,1,69)))
			Else 
				cRet := StrTran(cRet,"FRASE_PRECAUCAO",AllTrim(SubStr(cFrasesP,1,86)))
			Endif 

			IF Len(AllTrim(cFrasesP)) > 86 .Or. Len(AllTrim(cFrasesH)) > 69

				If nX == 1
					cRet := StrTran(cRet,"FRASE_1_PERIGO",AllTrim(SubStr(cFrasesH,70,82)))
				Else 
					cRet := StrTran(cRet,"FRASE_1_PRECAUCAO",AllTrim(SubStr(cFrasesP,86,108)))
				Endif 

			Else 
				cRet := StrTran(cRet,IIF(nX=1,"FRASE_1_PERIGO","FRASE_1_PRECAUCAO"),"")		
			Endif 

			If Len(AllTrim(cFrasesP)) > 174 .Or. Len(AllTrim(cFrasesH)) > 152

				If nX == 1
					cRet := StrTran(cRet,"FRASE_2_PERIGO",AllTrim(SubStr(cFrasesH,153,82)))
				Else 
					cRet := StrTran(cRet,"FRASE_2_PRECAUCAO",AllTrim(SubStr(cFrasesP,194,108)))
				Endif 

			Else
				cRet := StrTran(cRet,IIF(nX=1,"FRASE_2_PERIGO","FRASE_2_PRECAUCAO"),"")
			Endif 

			If Len(AllTrim(cFrasesP)) > 272 .Or. Len(AllTrim(cFrasesH)) > 235

				If nX == 1
					cRet := StrTran(cRet,"FRASE_3_PERIGO",AllTrim(SubStr(cFrasesH,236,82)))
				Else
					cRet := StrTran(cRet,"FRASE_3_PRECAUCAO",AllTrim(SubStr(cFrasesP,302,108)))
				Endif 

			Else
				cRet := StrTran(cRet,IIF(nX=1,"FRASE_3_PERIGO","FRASE_3_PRECAUCAO"),"")
			Endif 

			If Len(AllTrim(cFrasesP)) > 370 .Or. Len(AllTrim(cFrasesH)) > 318

				If nX == 1
					cRet := StrTran(cRet,"FRASE_4_PERIGO",AllTrim(SubStr(cFrasesH,319,88)))
				Else
					cRet := StrTran(cRet,"FRASE_4_PRECAUCAO",AllTrim(SubStr(cFrasesP,410,108)))
				Endif 

			Else
				cRet := StrTran(cRet,IIF(nX=1,"FRASE_4_PERIGO","FRASE_4_PRECAUCAO"),"")
			Endif 

		Next nX		
	/*
	Else //Tratativa para as demais impressoras
		
		For nX := 1 To 2

			If nX == 1 
				cRet := StrTran(cRet,"FRASE_PERIGO",AllTrim(SubStr(cFrasesH,1,78))) //StrTran(cRet,"FRASE_PERIGO",AllTrim(SubStr(cFrasesH,1,49))) 
			Else 
				cRet := StrTran(cRet,"FRASE_PRECAUCAO",AllTrim(SubStr(cFrasesP,1,80))) //StrTran(cRet,"FRASE_PRECAUCAO",AllTrim(SubStr(cFrasesP,1,47))) 
			Endif 

			If Len(AllTrim(cFrasesP)) > 48 .Or. Len(AllTrim(cFrasesH)) > 79

				If nX == 1
					cRet := StrTran(cRet,"FRASE_1_PERIGO",AllTrim(SubStr(cFrasesH,79,98))) //StrTran(cRet,"FRASE_1_PERIGO",AllTrim(SubStr(cFrasesH,50,71)))
				Else 
					cRet := StrTran(cRet,"FRASE_1_PRECAUCAO",AllTrim(SubStr(cFrasesP,81,100))) //StrTran(cRet,"FRASE_1_PRECAUCAO",AllTrim(SubStr(cFrasesP,48,71)))
				Endif 

			Else 
				cRet := StrTran(cRet,IIf(nX=1,"FRASE_1_PERIGO","FRASE_1_PRECAUCAO"),"")		
			Endif 

			If Len(AllTrim(cFrasesP)) > 181 .Or. Len(AllTrim(cFrasesH)) > 177

				If nX == 1
					cRet := StrTran(cRet,"FRASE_2_PERIGO",AllTrim(SubStr(cFrasesH,177,98))) //StrTran(cRet,"FRASE_2_PERIGO",AllTrim(SubStr(cFrasesH,121,71))) 
				Else 
					cRet := StrTran(cRet,"FRASE_2_PRECAUCAO",AllTrim(SubStr(cFrasesP,181,100))) //StrTran(cRet,"FRASE_2_PRECAUCAO",AllTrim(SubStr(cFrasesP,119,71))) 
				Endif 

			Else
				cRet := StrTran(cRet,IIf(nX=1,"FRASE_2_PERIGO","FRASE_2_PRECAUCAO"),"")
			Endif 

			If Len(AllTrim(cFrasesP)) > 281 .Or. Len(AllTrim(cFrasesH)) > 275

				If nX == 1
					cRet := StrTran(cRet,"FRASE_3_PERIGO",AllTrim(SubStr(cFrasesH,275,98))) //StrTran(cRet,"FRASE_3_PERIGO",AllTrim(SubStr(cFrasesH,192,71))) 
				Else
					cRet := StrTran(cRet,"FRASE_3_PRECAUCAO",AllTrim(SubStr(cFrasesP,281,100))) //StrTran(cRet,"FRASE_3_PRECAUCAO",AllTrim(SubStr(cFrasesP,190,71)))
				Endif 

			Else
				cRet := StrTran(cRet,IIF(nX=1,"FRASE_3_PERIGO","FRASE_3_PRECAUCAO"),"")
			Endif 

			If Len(AllTrim(cFrasesP)) > 258 .Or. Len(AllTrim(cFrasesH)) > 373

				If nX == 1
					cRet := StrTran(cRet,"FRASE_4_PERIGO",AllTrim(SubStr(cFrasesH,373,98)))  //StrTran(cRet,"FRASE_4_PERIGO",AllTrim(SubStr(cFrasesH,258,71))) 
				Else
					cRet := StrTran(cRet,"FRASE_4_PRECAUCAO",AllTrim(SubStr(cFrasesP,381,100))) //StrTran(cRet,"FRASE_4_PRECAUCAO",AllTrim(SubStr(cFrasesP,258,71))) 
				Endif 

			Else
				cRet := StrTran(cRet,IIF(nX=1,"FRASE_4_PERIGO","FRASE_4_PRECAUCAO"),"")
			Endif 

		Next nX		

	Endif		*/
	// ---

	//Convers�o dos caracteres da etiqueta
	cRet := Conversao(cRet)
	// ---

	//Grava��o do arquivo de log da forma��o da etiqueta
	MemoWrite(GetTempPath()+"\XCAVETQ1.txt",cRet)
	// ---

	//Tratativa da quantidade de etiquetas para impress�o
	If aPergs[3] == 0

		nQtde := 1

	Else 

		nQtde := aPergs[3]

	Endif 
	// ---

	For nX := 1 To nQtde

		MSCBPrinter(cModelo,cPorta,,,.F.,,,,,,.T.)
		MSCBChkStatus(.F.)
		MSCBBegin(1,6)
		MSCBWrite(cRet)
		MSCBEnd()
		MSCBClosePrinter()

	Next nX 

Return(cRet)

/*=================================================================
Autor: Pedro Vilas Boas / Vinicius N. de Oliveira
Data: 13/03/2025
Consultoria: Proativa
Uso: Calibre
Info: Fun��o que gera os arquivos contendo os strings que compoem 
cada etiqueta
*==================================================================*/
Static Function GeraArqEtq(cStrEtiq)

	Local cArqNovo := GetNextAlias()
	Local nHdlNovo

	cArqNovo := AllTrim(cArqNovo) + ".txt"
	nHdlNovo := FWFILEWRITER():New(_cDir + cArqNovo,.T.)
	
	If !nHdlNovo:Create()
		MsgAlert("O arquivo de nome "+_cDir+cArqNovo+" nao pode ser criado!!!","Atencao")
	Endif
	
	If !nHdlNovo:Write(cStrEtiq)
		MsgAlert("Ocorreu um erro na gravacao do arquivo. Continua?","Atencao!")
	Endif
	
	aAdd(aArqGerados, _cDir + cArqNovo)

	nHdlNovo:Close()

Return

/*=================================================================
Autor: Pedro Vilas Boas / Vinicius N. de Oliveira
Data: 13/03/2025
Consultoria: Proativa
Uso: Calibre
Info: Convers�o de caracteres do texto
*==================================================================*/
Static Function PergParam(aRet)

	Local aPergs   := {}
	Local cProduto := Space(TamSX3("B1_COD")[1])
	Local cLote    := Space(TamSX3("B8_LOTECTL")[1])
	Local nQtde    := 0
	Local lRet     := .F.

	aAdd( aPergs ,{1,"Produto : ",cProduto,"@!",'.T.','SB1','.T.',50,.F.})   
	aAdd( aPergs ,{1,"Lote : ",cLote,"@!",'.T.','','.T.',50,.F.}) 
	aAdd( aPergs ,{1,"Qtde : ",nQtde,"@E 9,999","Positivo()","",".T.",50,.F.})

	If ParamBox(aPergs ,"Parametros ",aRet)      
		lRet := .T.   
	Endif

Return(lRet)

/*=================================================================
Autor: Pedro Vilas Boas / Vinicius N. de Oliveira
Data: 13/03/2025
Consultoria: Proativa
Uso: Calibre
Info: Convers�o de caracteres do texto
*==================================================================*/
Static Function Conversao(cTexto)

	Local cRet := cTexto

	cRet := StrTran(cRet,"�","\A0")
	cRet := StrTran(cRet,"�","\82")
	cRet := StrTran(cRet,"�","\A1")
	cRet := StrTran(cRet,"�","\A2")
	cRet := StrTran(cRet,"�","\A3")
	cRet := StrTran(cRet,"�","\B5")
	cRet := StrTran(cRet,"�","\90")
	cRet := StrTran(cRet,"�","\D6")
	cRet := StrTran(cRet,"�","\E3")
	cRet := StrTran(cRet,"�","\E9")

	cRet := StrTran(cRet,"�","\C6")
	cRet := StrTran(cRet,"�","\E4")
	cRet := StrTran(cRet,"�","\C7")
	cRet := StrTran(cRet,"�","\E5")

	cRet := StrTran(cRet,"�","\83")
	cRet := StrTran(cRet,"�","\88")
	cRet := StrTran(cRet,"�","\93")
	cRet := StrTran(cRet,"�","\B6")
	cRet := StrTran(cRet,"�","\D2")
	cRet := StrTran(cRet,"�","\E2")

	cRet := StrTran(cRet,"�","\87")    
	cRet := StrTran(cRet,"�","\80")

	cRet := StrTran(cRet,"�","\A9")
	cRet := StrTran(cRet,"�","\85")
	cRet := StrTran(cRet,"�","\B7")

Return(cRet)

/*=================================================================
Autor: Pedro Vilas Boas / Vinicius N. de Oliveira
Data: 13/03/2025
Consultoria: Proativa
Uso: Calibre
Info: Valida��o do Lote
*==================================================================*/
Static Function ExistLote(cLote)

	Local lRet   := .F.
	Local cQuery := ""

	cQuery := "SELECT * FROM "+RetSQLName("SB8")+" WHERE D_E_L_E_T_ = '' AND B8_LOTECTL = '"+AllTrim(cLote)+"' "

	If Select("TMPSB8") > 0
		TMPSB8->(DbCloseArea())
	Endif

	DbUseArea( .T., "TOPCONN",TcGenQry( ,, cQuery ), "TMPSB8", .T., .F. )

	lRet := TMPSB8->(!EOF())

	TMPSB8->(DbCloseArea())
	
Return(lRet)

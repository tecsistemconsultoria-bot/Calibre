#Include 'Protheus.ch'

/***********************************************************************
Autor: Ot�vio Barreiro
Data: 30/03/2026
Consultoria: TecSistem Solu��es em Sistemas de Informa��o
Uso: Compras    
Rotina: Pedidos -> Eliminar Res�duos
Fun��o: MA235PC 
Info: Ponto de entrada que possibilita a elimina��o de res�duos
************************************************************************/
User Function MA235PC()  

Local cNum:= mv_par04
Local ExpL1 := .T.

DbSelectArea("SC7")
SC7->(DbSetOrder(1))      
SC7->(DBSeek(xFilial("SC7")+cNum))
    
If !Empty(SC7->C7_PO_EIC) .AND. FunName() <> "EICPO400"
    FWAlertWarning("Este PC esta associado a "+AllTrim(SC7->C7_PO_EIC)+" e so pode ter o residuo eliminado via EIC. Por favor, entre em contato com Comex!","ATENCAO:")
    ExpL1 := .F.
Else
    ExpL1 := .T.
EndIf
Return (ExpL1)

#Include 'Protheus.ch'

/***********************************************************************
Autor: Ot�vio Barreiro
Data: 30/03/2026
Consultoria: TecSistem Solu��es em Sistemas de Informa��o
Uso: Compras    
Rotina: SX1_VALID do Grupo MTA235
Fun��o: xVldResid 
Info: Valida��o para checar se em ambos os par�metros os pedido s�o iguais
************************************************************************/
User Function xVldResid(cDe,cAt)
Local lRet     := .T.

If cDe == cAt
    lRet     := .T.
Else
    FWAlertWarning("So e permitido eliminar residuo de um Pedido de Compra de cada vez", "ATENCAO")
    lRet     := .F.
EndIf 

Return(lRet)

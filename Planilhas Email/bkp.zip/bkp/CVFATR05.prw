#Include 'Protheus.ch'
#Include 'FWMVCDEF.CH'
#Include 'TopConn.ch'

/*/{Protheus.doc} CVFATR05
PVs com entregas atrasadas (C6_ENTREG < dDatabase) e a vencer em ate 5 dias.
Ignora itens com C6_BLQ = 'R'. Filtra apenas C5_TIPO = 'N'.
@author Nicolas
/*/
User Function CVFATR05()
    Local cEmails  := "otavio@tecsistemconsultoria.com.br"
    Local cTitulo  := "Relatorio de PVs - Entregas Atrasadas e a Vencer"
    Local cCorpo   := "Segue em anexo a planilha de Pedidos de Venda com entregas atrasadas e a vencer em ate 5 dias."
    Local cPath    := GetMV("XX_XARQUI",.F.,"\spool\")
    Local cData    := StrTran(DToS(Date()),"/","")
    Local cHora    := StrTran(Time(),":","")
    Local cDtHora  := AllTrim(cData+"_"+cHora)
    Local cNomeArq := "PVsAtrasados_"+cDtHora+".xml"
    Local cQuery   := ""
    Local cAlias   := ""
    Local oExcel   := FWMSEXCEL():New()

    // -- ABA 1: ATRASADOS (C6_ENTREG < dDatabase) --
    oExcel:AddWorkSheet("Atrasados")
    oExcel:AddTable("Atrasados", "Dados")
    oExcel:AddColumn("Atrasados", "Dados", "Filial",      1, 1)
    oExcel:AddColumn("Atrasados", "Dados", "Pedido",      1, 1)
    oExcel:AddColumn("Atrasados", "Dados", "Item",        1, 1)
    oExcel:AddColumn("Atrasados", "Dados", "Cliente",     1, 1)
    oExcel:AddColumn("Atrasados", "Dados", "Loja",        1, 1)
    oExcel:AddColumn("Atrasados", "Dados", "Nome",        1, 1)
    oExcel:AddColumn("Atrasados", "Dados", "Produto",     1, 1)
    oExcel:AddColumn("Atrasados", "Dados", "Qt Liberada", 1, 2)
    oExcel:AddColumn("Atrasados", "Dados", "Prc Venda",   1, 2)
    oExcel:AddColumn("Atrasados", "Dados", "Dt Entrega",  1, 3)
    oExcel:AddColumn("Atrasados", "Dados", "Dias Atraso", 1, 2)

    cQuery := " SELECT SC6.C6_FILIAL, SC6.C6_NUM, SC6.C6_ITEM, SC6.C6_CLI, SC6.C6_LOJA, "
    cQuery += "        SA1.A1_NOME, SC6.C6_PRODUTO, SC6.C6_QTDLIB, SC6.C6_PRCVEN, SC6.C6_ENTREG "
    cQuery += " FROM " + RetSqlName("SC6") + " SC6 "
    cQuery += " INNER JOIN " + RetSqlName("SC5") + " SC5 "
    cQuery += "         ON SC5.C5_FILIAL  = SC6.C6_FILIAL "
    cQuery += "        AND SC5.C5_NUM     = SC6.C6_NUM "
    cQuery += "        AND SC5.C5_TIPO    = 'N' "
    cQuery += "        AND SC5.C5_NOTA = '' "
    cQuery += "        AND SC5.C5_LIBEROK <> 'E' "
    cQuery += "        AND SC5.D_E_L_E_T_ = ' ' "
    cQuery += " LEFT JOIN " + RetSqlName("SA1") + " SA1 "
    cQuery += "         ON SA1.A1_COD     = SC6.C6_CLI "
    cQuery += "        AND SA1.A1_LOJA    = SC6.C6_LOJA "
    cQuery += "        AND SA1.D_E_L_E_T_ = ' ' "
    cQuery += " WHERE SC6.D_E_L_E_T_ = ' ' "
    cQuery += "   AND SC6.C6_ENTREG  <  '" + DTOS(dDatabase) + "' "
    cQuery += "   AND SC6.C6_ENTREG  <> ' ' "
    //cQuery += "   AND SC6.C6_NFISCAL =  ' ' "
    cQuery += "   AND SC6.C6_BLQ     <> 'R' "
    cQuery += " ORDER BY SC6.C6_ENTREG, SC6.C6_FILIAL, SC6.C6_NUM "

    cAlias := MPSysOpenQuery(cQuery)
    While !(cAlias)->(Eof())
        oExcel:AddRow("Atrasados", "Dados", { ;
            (cAlias)->C6_FILIAL,                  ;
            (cAlias)->C6_NUM,                     ;
            (cAlias)->C6_ITEM,                    ;
            (cAlias)->C6_CLI,                     ;
            (cAlias)->C6_LOJA,                    ;
            (cAlias)->A1_NOME,                    ;
            (cAlias)->C6_PRODUTO,                 ;
            (cAlias)->C6_QTDLIB,                  ;
            (cAlias)->C6_PRCVEN,                  ;
            STOD((cAlias)->C6_ENTREG),            ;
            dDatabase - STOD((cAlias)->C6_ENTREG) ;
        })
        (cAlias)->(DbSkip())
    EndDo
    (cAlias)->(DbCloseArea())

    // -- ABA 2: A VENCER (C6_ENTREG entre dDatabase e dDatabase+5) --
    oExcel:AddWorkSheet("A_Vencer")
    oExcel:AddTable("A_Vencer", "Dados")
    oExcel:AddColumn("A_Vencer", "Dados", "Filial",        1, 1)
    oExcel:AddColumn("A_Vencer", "Dados", "Pedido",        1, 1)
    oExcel:AddColumn("A_Vencer", "Dados", "Item",          1, 1)
    oExcel:AddColumn("A_Vencer", "Dados", "Cliente",       1, 1)
    oExcel:AddColumn("A_Vencer", "Dados", "Loja",          1, 1)
    oExcel:AddColumn("A_Vencer", "Dados", "Nome",          1, 1)
    oExcel:AddColumn("A_Vencer", "Dados", "Produto",       1, 1)
    oExcel:AddColumn("A_Vencer", "Dados", "Qt Liberada",   1, 2)
    oExcel:AddColumn("A_Vencer", "Dados", "Prc Venda",     1, 2)
    oExcel:AddColumn("A_Vencer", "Dados", "Dt Entrega",    1, 3)
    oExcel:AddColumn("A_Vencer", "Dados", "Dias p/Vencer", 1, 2)

    cQuery := " SELECT SC6.C6_FILIAL, SC6.C6_NUM, SC6.C6_ITEM, SC6.C6_CLI, SC6.C6_LOJA, "
    cQuery += "        SA1.A1_NOME, SC6.C6_PRODUTO, SC6.C6_QTDLIB, SC6.C6_PRCVEN, SC6.C6_ENTREG "
    cQuery += " FROM " + RetSqlName("SC6") + " SC6 "
    cQuery += " INNER JOIN " + RetSqlName("SC5") + " SC5 "
    cQuery += "         ON SC5.C5_FILIAL  = SC6.C6_FILIAL "
    cQuery += "        AND SC5.C5_NUM     = SC6.C6_NUM "
    cQuery += "        AND SC5.C5_TIPO    = 'N' "
    cQuery += "        AND SC5.C5_NOTA = '' "
    cQuery += "        AND SC5.C5_LIBEROK <> 'E' "
    cQuery += "        AND SC5.D_E_L_E_T_ = ' ' "
    cQuery += " LEFT JOIN " + RetSqlName("SA1") + " SA1 "
    cQuery += "         ON SA1.A1_COD     = SC6.C6_CLI "
    cQuery += "        AND SA1.A1_LOJA    = SC6.C6_LOJA "
    cQuery += "        AND SA1.D_E_L_E_T_ = ' ' "
    cQuery += " WHERE SC6.D_E_L_E_T_ = ' ' "
    cQuery += "   AND SC6.C6_ENTREG  >= '" + DTOS(dDatabase) + "' "
    cQuery += "   AND SC6.C6_ENTREG  <= '" + DTOS(dDatabase + 5) + "' "
    cQuery += "   AND SC6.C6_BLQ     <> 'R' "
    cQuery += " ORDER BY SC6.C6_ENTREG, SC6.C6_FILIAL, SC6.C6_NUM "

    cAlias := MPSysOpenQuery(cQuery)
    While !(cAlias)->(Eof())
        oExcel:AddRow("A_Vencer", "Dados", { ;
            (cAlias)->C6_FILIAL,                  ;
            (cAlias)->C6_NUM,                     ;
            (cAlias)->C6_ITEM,                    ;
            (cAlias)->C6_CLI,                     ;
            (cAlias)->C6_LOJA,                    ;
            (cAlias)->A1_NOME,                    ;
            (cAlias)->C6_PRODUTO,                 ;
            (cAlias)->C6_QTDLIB,                  ;
            (cAlias)->C6_PRCVEN,                  ;
            STOD((cAlias)->C6_ENTREG),            ;
            STOD((cAlias)->C6_ENTREG) - dDatabase ;
        })
        (cAlias)->(DbSkip())
    EndDo
    (cAlias)->(DbCloseArea())

    oExcel:Activate()
    oExcel:GetXMLFile(cPath + cNomeArq)
    xEnvMail(cPath + cNomeArq, cEmails, cTitulo, cCorpo)

Return

/*=================================================================
Autor: Vinicius N. de Oliveira
Data: 04/12/2025
Consultoria: TecSistem Consultoria em Sistemas de Informacao
Uso: Calibre
Info: Envio de e-mail
*==================================================================*/
Static Function xEnvMail(cArquivo,cEmail,cAssunto,cCorpo)

	Local cAssuntoFinal := If(Empty(cAssunto), "Relatorio", cAssunto)
	Local cBodyFinal    := If(Empty(cCorpo), "Segue em anexo relatorio.", cCorpo)
	Local lMailAuth	:= GetMV("MV_RELAUTH",.F.,.T.)
	Local nPortSMTP := 587
	Local nTimeout  := GetMV("MV_RELTIME")
	Local xRet
	Local oServer	
	Local oMessage

    Private cMailConta  := Alltrim(GetMV("MV_RELACNT"))
	Private cMailServer := AllTrim(GetMV("MV_RELSERV"))
	Private cMailSenha  := Alltrim(GetMV("MV_RELPSW"))
	Private nPosPort    := AT(":", cMailServer)

	If nPosPort > 0
		nPortSMTP   := Val(SubStr(cMailServer, nPosPort+1))
		cMailServer := AllTrim(SubStr(cMailServer, 1, nPosPort-1))
	EndIf

	If Empty(cArquivo) .Or. Empty(cEmail)
		Return .F.
	EndIf

	oServer := TMailManager():New()
	oServer:SetUseTLS(.T.)
	oServer:SetUseSSL(.T.)

    xRet := oServer:Init( "", cMailServer, Alltrim(GetMV("MV_RELFROM",.F.,"no-reply@carvalhaes.net")), cMailSenha,, nPortSMTP )

	If xRet <> 0
		MsgAlert("O servidor SMTP nao foi inicializado: " + oServer:GetErrorString( xRet ))
		Return .F.
	EndIf

	xRet := oServer:SetSMTPTimeout(nTimeout)

	If xRet <> 0
		MsgAlert("Tempo limite para " + cValToChar( nTimeout ))
	EndIf

	xRet := oServer:SMTPConnect()

	If xRet <> 0
		MsgAlert("Nao foi possivel conectar ao server SMTP: " + oServer:GetErrorString( xRet ))
		Return .F.
	EndIf

	If lMailAuth

		xRet := oServer:SmtpAuth( cMailConta, cMailSenha )

		If xRet <> 0
			MsgAlert("Nao foi possivel autenticar no server SMTP: " + oServer:GetErrorString( xRet ))
			oServer:SMTPDisconnect()
			Return .F.
		EndIf

	EndIf

	oMessage := TMailMessage():New()

	oMessage:Clear()

	oMessage:cDate	  := cValToChar(Date())
	oMessage:cFrom 	  := AllTrim(GetMV("MV_RELFROM",.F.,"no-reply@carvalhaes.net"))
	oMessage:cTo 	  := cEmail
	oMessage:cSubject := cAssuntoFinal
	oMessage:cBody 	  := cBodyFinal

	xRet := oMessage:AttachFile(cArquivo)

	If xRet < 0
		MsgAlert("Nao foi possivel anexar o arquivo: " + cArquivo)
		oServer:SMTPDisconnect()
		Return .F.
	EndIf

	xRet := oMessage:Send( oServer )

	If xRet <> 0
		MsgAlert("Nao foi possivel enviar o relatorio: " + oServer:GetErrorString( xRet ))
	Else
		//MsgAlert("Relatorio enviado com sucesso...")
	EndIf

	xRet := oServer:SMTPDisconnect()

	If xRet <> 0
		MsgAlert("Nao foi possivel desconectar o servidor SMTP: " + oServer:GetErrorString( xRet ))
	Else
		//MsgAlert("["+DToc(dDatabase)+"-"+Time()+"] Server desconectado com sucesso...")
	EndIf

Return .T.

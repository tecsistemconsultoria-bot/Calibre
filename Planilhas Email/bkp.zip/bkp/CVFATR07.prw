#Include 'Protheus.ch'
#Include 'FWMVCDEF.CH'
#Include 'TopConn.ch'

/*/{Protheus.doc} CVFATR07
Licencas dos clientes e produtos anuentes que expirarao em ATE 5 DIAS.
Ignora ZPx_MSBLQL = '1'
@author Nicolas
/*/
User Function CVFATR07()
    Local cEmails  := "otavio@tecsistemconsultoria.com.br"
    Local cTitulo  := "Licencas a Vencer (Ate 5 Dias)"
    Local cCorpo   := "Segue em anexo a planilha de licencas de Clientes (ZP1) e Produtos (ZP2) a vencer."
    Local cPath    := GetMV("XX_XARQUI",.F.,"\spool\")
    Local cData    := StrTran(DToS(Date()),"/","")
    Local cHora    := StrTran(Time(),":","")
    Local cDtHora  := AllTrim(cData+"_"+cHora)
    Local cNomeArq := "Licencas_A_Vencer_"+cDtHora+".xml"
    Local cQuery   := ""
    Local cAlias   := ""
    Local oExcel   := FWMSEXCEL():New()
    
    // -- ABA 1: CLIENTES (ZP1) --
    oExcel:AddworkSheet("Clientes_ZP1")
    oExcel:AddTable("Clientes_ZP1", "Dados")
    oExcel:AddColumn("Clientes_ZP1", "Dados", "Filial", 1, 1)
    oExcel:AddColumn("Clientes_ZP1", "Dados", "Codigo", 1, 1)
    oExcel:AddColumn("Clientes_ZP1", "Dados", "Dt Validade", 1, 3)

    cQuery := " SELECT * FROM " + RetSqlName("ZP1") + " ZP1 "
    cQuery += " WHERE ZP1.D_E_L_E_T_ = ' ' "
    //N�o tem esse campo na base teste 
	//cQuery += "   AND ZP1.ZP1_MSBLQL <> '1' "
    cQuery += "   AND ZP1.ZP1_DTVLD >= '" + DTOS(dDataBase) + "' "
    cQuery += "   AND ZP1.ZP1_DTVLD <= '" + DTOS(dDataBase + 5) + "' "
    
    cAlias := MPSysOpenQuery(cQuery)
    While !(cAlias)->(Eof())
        oExcel:AddRow("Clientes_ZP1", "Dados", { ;
            (cAlias)->ZP1_FILIAL, ;
            (cAlias)->ZP1_CODCLI, ; 
            STOD((cAlias)->ZP1_DTVLD) ;
        })
        (cAlias)->(DbSkip())
    EndDo
    (cAlias)->(DbCloseArea())

    // -- ABA 2: PRODUTOS (ZP2) --
    oExcel:AddworkSheet("Produtos_ZP2")
    oExcel:AddTable("Produtos_ZP2", "Dados")
    oExcel:AddColumn("Produtos_ZP2", "Dados", "Filial", 1, 1)
    oExcel:AddColumn("Produtos_ZP2", "Dados", "Codigo", 1, 1) 
    oExcel:AddColumn("Produtos_ZP2", "Dados", "Dt Validade", 1, 3)

    cQuery := " SELECT * FROM " + RetSqlName("ZP2") + " ZP2 "
    cQuery += " WHERE ZP2.D_E_L_E_T_ = ' ' "
    cQuery += "   AND ZP2.ZP2_MSBLQL <> '1' "
    cQuery += "   AND ZP2.ZP2_DTVLD >= '" + DTOS(dDataBase) + "' "
    cQuery += "   AND ZP2.ZP2_DTVLD <= '" + DTOS(dDataBase + 5) + "' "
    
    cAlias := MPSysOpenQuery(cQuery)
    While !(cAlias)->(Eof())
        oExcel:AddRow("Produtos_ZP2", "Dados", { ;
            (cAlias)->ZP2_FILIAL, ;
            (cAlias)->ZP2_CODCLI, ; 
            STOD((cAlias)->ZP2_DTVLD) ;
        })
        (cAlias)->(DbSkip())
    EndDo
    (cAlias)->(DbCloseArea())

    oExcel:Activate()
    oExcel:GetXMLFile(cPath + cNomeArq)
	FreeObj(oExcel) 
    xEnvMail(cPath + cNomeArq, cEmails, cTitulo, cCorpo)
Return

/*=================================================================
Autor: Vinicius N. de Oliveira
Data: 04/12/2025
Consultoria: TecSistem Consultoria em Sistemas de Informacao
Uso: Calibre
Info: Envio de e-mail 
*==================================================================*/
Static Function xEnvMail(cArquivo,cEmail,cAssunto,cCorpo)

	Local cAssuntoFinal := If(Empty(cAssunto), "Relatorio", cAssunto)
	Local cBodyFinal    := If(Empty(cCorpo), "Segue em anexo relatorio.", cCorpo)
	Local lMailAuth	:= GetMV("MV_RELAUTH",.F.,.T.) //Autenticacao com server SMTP
	Local nPortSMTP := 587
	Local nTimeout  := GetMV("MV_RELTIME")
	Local xRet
	Local oServer	
	Local oMessage

    Private cMailConta  := Alltrim(GetMV("MV_RELACNT"))
	Private cMailServer := AllTrim(GetMV("MV_RELSERV"))
	Private cMailSenha  := Alltrim(GetMV("MV_RELPSW"))
	Private nPosPort    := AT(":", cMailServer)

	If nPosPort > 0
		nPortSMTP   := Val(SubStr(cMailServer, nPosPort+1))
		cMailServer := AllTrim(SubStr(cMailServer, 1, nPosPort-1))
	EndIf

	If Empty(cArquivo) .Or. Empty(cEmail)
		Return .F.
	EndIf

	oServer := TMailManager():New()
	oServer:SetUseTLS(.T.)
	oServer:SetUseSSL(.T.)

    xRet := oServer:Init( "", cMailServer, Alltrim(GetMV("MV_RELFROM",.F.,"no-reply@carvalhaes.net")), cMailSenha,, nPortSMTP )

	If xRet <> 0
		MsgAlert("O servidor SMTP nao foi inicializado: " + oServer:GetErrorString( xRet ))
		Return .F.
	EndIf

	xRet := oServer:SetSMTPTimeout(nTimeout)

	If xRet <> 0
		MsgAlert("Tempo limite para " + cValToChar( nTimeout ))
	EndIf

	xRet := oServer:SMTPConnect()

	If xRet <> 0
		MsgAlert("Nao foi possivel conectar ao server SMTP: " + oServer:GetErrorString( xRet ))
		Return .F.
	EndIf

	If lMailAuth

		xRet := oServer:SmtpAuth( cMailConta, cMailSenha )

		If xRet <> 0
			MsgAlert("Nao foi possivel autenticar no server SMTP: " + oServer:GetErrorString( xRet ))
			oServer:SMTPDisconnect()
			Return .F.
		EndIf

	EndIf
	
	oMessage := TMailMessage():New()

	oMessage:Clear()

	oMessage:cDate	  := cValToChar(Date())
	oMessage:cFrom 	  := AllTrim(GetMV("MV_RELFROM",.F.,"no-reply@carvalhaes.net"))
	oMessage:cTo 	  := cEmail
	oMessage:cSubject := cAssuntoFinal
	oMessage:cBody 	  := cBodyFinal

	xRet := oMessage:AttachFile(cArquivo)
	
	If xRet < 0
		MsgAlert("Nao foi possivel anexar o arquivo: " + cArquivo)
	EndIf

	xRet := oMessage:Send( oServer )

	If xRet <> 0
		MsgAlert("Nao foi possivel enviar o relatorio: " + oServer:GetErrorString( xRet ))
	Else
		//MsgAlert("Relatorio enviado com sucesso...")
	EndIf

	xRet := oServer:SMTPDisconnect()

	If xRet <> 0
		MsgAlert("Nao foi possivel desconectar o servidor SMTP: " + oServer:GetErrorString( xRet ))
	Else
		//MsgAlert("["+DToc(dDatabase)+"-"+Time()+"] Server desconectado com sucesso...")
	EndIf

Return .T.

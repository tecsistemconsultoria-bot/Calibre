#Include 'Protheus.ch'
#Include 'FWMVCDEF.CH'
#Include 'TopConn.ch'

/*/{Protheus.doc} CVFATR04
Relat�rio Di�rio de Faturamento
Autor  : Nicolas B. Fernandes
Descri��o: Gera planilha Excel com 3 abas (Sem Bloqueios / Com Bloqueios / Carteira)
           e envia por e-mail. Projetado para rodar como JOB noturno.

Filtros:
  Sem Bloqueios : C5_TIPO='N', F4_ESTOQUE='S', C9_CRVENT=dDatabase+1,
                  C9_BLEST='' E todos os outros bloqueios = ''
  Com Bloqueios : C5_TIPO='N', F4_ESTOQUE='S', C9_CRVENT=dDatabase+1,
                  C9_BLEST='' E pelo menos um outro bloqueio <> ''
  Carteira(SZV) : ZV_DTFAT = dDatabase+1
/*/
User Function CVFATR04()
    Local cEmails    := "otavio@tecsistemconsultoria.com.br"
    Local cTitulo    := "Relatorio Diario de Faturamento - Protheus"
    Local cCorpo     := ""
    Local cPath      := GetMV("XX_XARQUI",.F.,"\spool\")
    Local cData      := StrTran(DToS(Date()),"/","")
    Local cHora      := StrTran(Time(),":","")
    Local cDtHora    := AllTrim(cData+"_"+cHora)
    Local cNomeArq   := "Faturamento_"+cDtHora+".xml"
    Local nVlrPronto := 0
    Local nVlrBloq   := 0
    Local nVlrCart   := 0
    Local lAbreEnv   := .F.

    // Prepara��o do Ambiente: suporta JOB (sem SX2 ativo) ou execu��o via Menu
    If Select("SX2") <= 0
        RPCSetEnv("01", "01", "proativa", "Calibre@2025", "FAT")
        lAbreEnv := .T.
    EndIf

    If !ExistDir(cPath)
        MakeDir(cPath)
    EndIf

    // Gera o Excel com as 3 abas � totalizadores retornados por refer�ncia
    GerarPlanilha(cPath + cNomeArq, @nVlrPronto, @nVlrBloq, @nVlrCart)

    // Montagem do corpo HTML do e-mail
    cCorpo := '<html><body style="font-family: Calibri, sans-serif;">'
    cCorpo += '<h2>Resumo de Faturamento</h2>'
    cCorpo += '<p>Seguem os valores consolidados para faturamento em <b>' + dToC(Date() + 1) + '</b>:</p>'
    cCorpo += '<ul>'
    cCorpo += '  <li><b>R$ ' + Transform(nVlrPronto, "@E 999,999,999.92") + '</b> &ndash; sem bloqueios (pronto para faturar)</li>'
    cCorpo += '  <li><b>R$ ' + Transform(nVlrBloq,   "@E 999,999,999.92") + '</b> &ndash; com bloqueio (mas com estoque)</li>'
    cCorpo += '  <li><b>TOTAL R$ ' + Transform(nVlrPronto + nVlrBloq, "@E 999,999,999.92") + '</b></li>'
    cCorpo += '</ul>'
    cCorpo += '<p><i>Anexo: abas Sem bloqueios, Com bloqueios e Carteira (SZV).</i></p>'
    cCorpo += '<br><hr><font size="1">Gerado automaticamente pelo Protheus - ' + Time() + '</font>'
    cCorpo += '</body></html>'

    // Envia o e-mail com o arquivo em anexo
    
    xEnvMail(cPath + cNomeArq, cEmails, cTitulo, cCorpo)

    // Encerra o ambiente somente se foi esta rotina que o abriu
    If lAbreEnv
        RPCClearEnv()
    EndIf

Return

//--------------------------------------------------------------------
// GerarPlanilha
// Monta o arquivo Excel (.xml) com 3 abas.
// Totalizadores retornados por refer�ncia (@).
//--------------------------------------------------------------------
Static Function GerarPlanilha(cFullNome, nVlrPronto, nVlrBloq, nVlrCart)
    Local oExcel     := FWMSEXCEL():New()
    Local cQuery     := ""
    Local cAlias     := ""
    Local dAmanha    := dDatabase + 1
    Local nTotalItem := 0
    Local lBloqueado := .F.
    Local aLinha     := {}
    Local aTotPronto := Array(48) // Refatorado: agora com 48 colunas exatas
    Local aTotBloq   := Array(48)
    Local cStatusC9  := ""

    nVlrPronto := 0
    nVlrBloq   := 0
    nVlrCart   := 0

    //================================================================
    // QUERY PRINCIPAL � SC9 (Pedidos Liberados)
    //================================================================
    cQuery := " SELECT "
    cQuery += "   SC9.R_E_C_N_O_ AS SC9REC, " // <-- Adicionado para o DbGoto funcionar na UDF
    cQuery += "   SC9.C9_FILIAL, "
    cQuery += "   SC9.C9_PEDIDO, "
    cQuery += "   SC9.C9_ITEM, "
    cQuery += "   SC9.C9_CLIENTE, "
    cQuery += "   SC9.C9_LOJA, "
    cQuery += "   SA1.A1_NOME, "
    cQuery += "   SC5.C5_CONDPAG, "
    
    // --- Campos Virtuais que agora v�m de joins reais ---
    cQuery += "   SC5.C5_TIPO, "
    cQuery += "   SC5.C5_TRANSP, "
    cQuery += "   SA4.A4_NOME AS NOMETRAN, "
    
    cQuery += "   SC9.C9_PRODUTO, "
    cQuery += "   SC9.C9_QTDLIB, "        // Quantidade Liberada         (N,12,2)
    cQuery += "   SC9.C9_PRCVEN, "        // Pre�o de Venda              (N,14,2)
    cQuery += "   SC9.C9_NFISCAL, "       // Nota Fiscal                 (C,9)
    cQuery += "   SC9.C9_SERIENF, "       // S�rie da NF                 (C,3)
    cQuery += "   SC9.C9_DATALIB, "       // Data da Libera��o           (D,8)  -- STOD() no loop
    cQuery += "   SC9.C9_SEQUEN, "        // Sequ�ncia                   (C,2)
    cQuery += "   SC9.C9_CRVENT, "        // Data p/Faturar (custom)     (C,8)  -- STOD() no loop
    cQuery += "   SC9.C9_GRUPO, "         // Grupo de Estoque            (C,4)
    cQuery += "   SC9.C9_AGREG, "         // Agregador de Libera��o      (C,4)  ** nativo
    cQuery += "   SC9.C9_ITEMREM, "       // Item do Remito              (C,2)
    cQuery += "   SC9.C9_REMITO, "        // N� do Remito                (C,9)
    cQuery += "   SC9.C9_LOCAL, "         // Armaz�m                     (C,2)
    cQuery += "   SC9.C9_LOTECTL, "       // Lote (rastreabilidade)      (C,10) ** nativo
    cQuery += "   SC9.C9_CARGA, "         // N� da Carga                 (C,6)
    cQuery += "   SC9.C9_SEQCAR, "        // Sequ�ncia da Carga          (C,2)
    cQuery += "   SC9.C9_SEQENT, "        // Sequ�ncia de Entrega        (C,6)
    cQuery += "   SC9.C9_SERVIC, "        // Tipo de Servi�o WMS         (C,3)
    cQuery += "   SC9.C9_ENDPAD, "        // Endere�o Envio Padr�o       (C,15)
    cQuery += "   SC9.C9_TPESTR, "        // Estrutura F�sica            (C,6)  ** nativo
    cQuery += "   SC9.C9_QTDLIB2, "       // Qt Liberada 2� UM           (N,12,2)
    cQuery += "   SC9.C9_RETOPER, "       // Ret�m PIS/COFINS            (C,1)
    cQuery += "   SC9.C9_TRT, "           // Sequ�ncia do Empenho        (C,3)  ** nativo
    cQuery += "   SC6.C6_ENTREG, "        // Data de Entrega (SC6)       (D,8)  -- STOD() no loop
    // --- Bloqueios nativos ---
    cQuery += "   SC9.C9_BLCRED, "        // Bloqueio de Cr�dito         (C,2)
    cQuery += "   SC9.C9_BLEST, "         // Bloqueio de Estoque         (C,2)
    cQuery += "   SC9.C9_BLWMS, "         // Bloqueio WMS                (C,2)
    cQuery += "   SC9.C9_BLINF, "         // Informa��o de Bloqueio      (C,30) ** nativo
    cQuery += "   SC9.C9_BLTMS, "         // Bloqueio TMS                (C,2)
    // --- Bloqueios customizados do cliente ---
    cQuery += "   SC9.C9_BLQPAG, "
    cQuery += "   SC9.C9_BLQFRT, "
    cQuery += "   SC9.C9_BLQTRAN, "
    cQuery += "   SC9.C9_BLQDESC, "
    cQuery += "   SC9.C9_BLQDTV, "
    cQuery += "   SC9.C9_XBLPVTO, "
    cQuery += "   SC9.C9_XBLQRC "
    cQuery += " FROM "  + RetSqlName("SC9") + " SC9 "
    cQuery += " INNER JOIN " + RetSqlName("SC5") + " SC5 "
    cQuery += "         ON SC5.C5_FILIAL  = SC9.C9_FILIAL "
    cQuery += "        AND SC5.C5_NUM     = SC9.C9_PEDIDO "
    cQuery += "        AND SC5.D_E_L_E_T_ = ' ' "
    cQuery += " INNER JOIN " + RetSqlName("SC6") + " SC6 "
    cQuery += "         ON SC6.C6_FILIAL  = SC9.C9_FILIAL "
    cQuery += "        AND SC6.C6_NUM     = SC9.C9_PEDIDO "
    cQuery += "        AND SC6.C6_ITEM    = SC9.C9_ITEM "
    cQuery += "        AND SC6.C6_PRODUTO = SC9.C9_PRODUTO "
    cQuery += "        AND SC6.D_E_L_E_T_ = ' ' "
    cQuery += " INNER JOIN " + RetSqlName("SF4") + " SF4 "
    cQuery += "         ON SF4.F4_CODIGO  = SC6.C6_TES "
    cQuery += "        AND SF4.D_E_L_E_T_ = ' ' "
    cQuery += " LEFT  JOIN " + RetSqlName("SA1") + " SA1 "
    cQuery += "         ON SA1.A1_COD     = SC9.C9_CLIENTE "
    cQuery += "        AND SA1.A1_LOJA    = SC9.C9_LOJA "
    cQuery += "        AND SA1.D_E_L_E_T_ = ' ' "
    
    // <-- Adicionado JOIN com SA4 para pegar o nome da Transportadora
    cQuery += " LEFT  JOIN " + RetSqlName("SA4") + " SA4 "
    cQuery += "         ON SA4.A4_COD     = SC5.C5_TRANSP "
    cQuery += "        AND SA4.D_E_L_E_T_ = ' ' "
    
    cQuery += " WHERE SC9.D_E_L_E_T_ = ' ' "
    cQuery += "   AND SC5.C5_TIPO    = 'N' "                        // Pedido tipo Normal
    cQuery += "   AND SF4.F4_ESTOQUE = 'S' "                        // TES que movimenta estoque
    cQuery += "   AND SC9.C9_CRVENT  = '" + DTOS(dAmanha) + "' "   // Programado p/ faturar amanh�
    cQuery += " ORDER BY SC9.C9_FILIAL, SC9.C9_PEDIDO, SC9.C9_ITEM "

    cAlias := MPSysOpenQuery(cQuery)

    // Cria as duas abas antes de iniciar o loop
    oExcel:AddworkSheet("Sem bloqueios")
    oExcel:AddTable("Sem bloqueios", "Prontos")
    MontaColunasMATA460(oExcel, "Sem bloqueios", "Prontos")

    oExcel:AddworkSheet("Com bloqueios")
    oExcel:AddTable("Com bloqueios", "Bloqueados")
    MontaColunasMATA460(oExcel, "Com bloqueios", "Bloqueados")

    While !(cAlias)->(Eof())

        // C9_XVLTOT j� � este c�lculo, guardamos na vari�vel
        nTotalItem := (cAlias)->C9_QTDLIB * (cAlias)->C9_PRCVEN
        lBloqueado := .F.

        If !Empty((cAlias)->C9_BLEST)
            (cAlias)->(DbSkip())
            Loop
        EndIf

        If !Empty((cAlias)->C9_BLCRED)  .Or. ;
           !Empty((cAlias)->C9_BLWMS)   .Or. ;
           !Empty((cAlias)->C9_BLINF)   .Or. ;
           !Empty((cAlias)->C9_BLTMS)   .Or. ;
           !Empty((cAlias)->C9_BLQPAG)  .Or. ;
           !Empty((cAlias)->C9_BLQFRT)  .Or. ;
           !Empty((cAlias)->C9_BLQTRAN) .Or. ;
           !Empty((cAlias)->C9_BLQDESC) .Or. ;
           !Empty((cAlias)->C9_BLQDTV)  .Or. ;
           !Empty((cAlias)->C9_XBLPVTO) .Or. ;
           !Empty((cAlias)->C9_XBLQRC)
            lBloqueado := .T.
        EndIf

        // --- C9_XSTATUS: Posiciona fisicamente a SC9 para a sua UDF funcionar ---
        SC9->(DbGoto( (cAlias)->SC9REC ))
        cStatusC9 := U_GETSTATUSC9()

        // Monta a linha com as novas colunas
        aLinha := { ;
            (cAlias)->C9_FILIAL,                ;  //  1  Filial
            (cAlias)->C9_PEDIDO,                ;  //  2  Pedido
            (cAlias)->C9_ITEM,                  ;  //  3  Item
            (cAlias)->C9_CLIENTE,               ;  //  4  Cliente
            (cAlias)->C9_LOJA,                  ;  //  5  Loja
            (cAlias)->A1_NOME,                  ;  //  6  Nome Cliente
            (cAlias)->C5_CONDPAG,               ;  //  7  Cond. Pgto
            (cAlias)->C5_TIPO,                  ;  //  8  Tipo Pedido (C9_XTIPO)
            (cAlias)->C5_TRANSP,                ;  //  9  Transportadora (C9_XTRANSP)
            (cAlias)->NOMETRAN,                 ;  // 10  Nome Transp (C9_XNTRANS)
            cStatusC9,                          ;  // 11  Status (C9_XSTATUS)
            (cAlias)->C9_PRODUTO,               ;  // 12  Produto
            (cAlias)->C9_QTDLIB,                ;  // 13  Qt Liberada
            (cAlias)->C9_PRCVEN,                ;  // 14  Prc Venda
            nTotalItem,                         ;  // 15  R$ Total / C9_XVLTOT
            (cAlias)->C9_NFISCAL,               ;  // 16  Nota Fiscal
            (cAlias)->C9_SERIENF,               ;  // 17  S�rie NF
            STOD((cAlias)->C9_DATALIB),         ;  // 18  Dt Libera��o
            (cAlias)->C9_SEQUEN,                ;  // 19  Sequ�ncia
            STOD((cAlias)->C9_CRVENT),          ;  // 20  Dt p/Faturar
            (cAlias)->C9_GRUPO,                 ;  // 21  Grupo
            (cAlias)->C9_AGREG,                 ;  // 22  Agreg. Liber
            (cAlias)->C9_ITEMREM,               ;  // 23  Item Remito
            (cAlias)->C9_REMITO,                ;  // 24  N. Remito
            (cAlias)->C9_LOCAL,                 ;  // 25  Armaz�m
            (cAlias)->C9_LOTECTL,               ;  // 26  Lote
            (cAlias)->C9_CARGA,                 ;  // 27  Carga
            (cAlias)->C9_SEQCAR,                ;  // 28  Seq. Carga
            (cAlias)->C9_SEQENT,                ;  // 29  Seq. Entrega
            (cAlias)->C9_SERVIC,                ;  // 30  Servi�o
            (cAlias)->C9_ENDPAD,                ;  // 31  End. Padr�o
            (cAlias)->C9_TPESTR,                ;  // 32  Estr. F�sica
            (cAlias)->C9_QTDLIB2,               ;  // 33  Qt Liberada 2
            (cAlias)->C9_RETOPER,               ;  // 34  Ret. Opera��o
            (cAlias)->C9_TRT,                   ;  // 35  Seq. Empenho
            STOD((cAlias)->C6_ENTREG),          ;  // 36  Dt Entrega (da SC6)
            (cAlias)->C9_BLCRED,                ;  // 37  Bloq. Cr�dito
            (cAlias)->C9_BLEST,                 ;  // 38  Bloq. Estoque
            (cAlias)->C9_BLWMS,                 ;  // 39  Bloq. WMS
            (cAlias)->C9_BLINF,                 ;  // 40  Inf. Bloqueio
            (cAlias)->C9_BLTMS,                 ;  // 41  Bloq. TMS
            (cAlias)->C9_BLQPAG,                ;  // 42  Bloq. Pag
            (cAlias)->C9_BLQFRT,                ;  // 43  Bloq. Frete
            (cAlias)->C9_BLQTRAN,               ;  // 44  Blq. Transp.
            (cAlias)->C9_BLQDESC,               ;  // 45  Blq. Desc.
            (cAlias)->C9_BLQDTV,                ;  // 46  Blq. Validade
            (cAlias)->C9_XBLPVTO,               ;  // 47  Blq. PVTO
            (cAlias)->C9_XBLQRC                 ;  // 48  Blq. RC
        }

        If lBloqueado
            oExcel:AddRow("Com bloqueios", "Bloqueados", aLinha)
            nVlrBloq += nTotalItem
        Else
            oExcel:AddRow("Sem bloqueios", "Prontos", aLinha)
            nVlrPronto += nTotalItem
        EndIf

        (cAlias)->(DbSkip())
    End  // While SC9
    (cAlias)->(DbCloseArea())

    // Linhas de TOTAL � Refatoradas para limpar o c�digo e n�o ter erro de array
    AFill(aTotPronto, "")
    aTotPronto[1]  := "TOTAL"
    aTotPronto[15] := nVlrPronto // Posi��o 15 agora � o R$ Total

    AFill(aTotBloq, "")
    aTotBloq[1]  := "TOTAL"
    aTotBloq[15] := nVlrBloq

    oExcel:AddRow("Sem bloqueios", "Prontos",    aTotPronto)
    oExcel:AddRow("Com bloqueios", "Bloqueados", aTotBloq)

    //================================================================
    // ABA 3 � CARTEIRA (SZV)
    // Filtro: ZV_DTFAT = dDatabase + 1
    //================================================================
    oExcel:AddworkSheet("Carteira")
    oExcel:AddTable("Carteira", "SZV")
    oExcel:AddColumn("Carteira", "SZV", "Documento", 1, 1)
    oExcel:AddColumn("Carteira", "SZV", "Data Fat",  1, 3)
    oExcel:AddColumn("Carteira", "SZV", "Valor",     1, 2)

    cQuery := " SELECT ZV_PEDIDO, ZV_DTFAT, ZV_TOTAL "
    cQuery += " FROM "  + RetSqlName("SZV") + " "
    cQuery += " WHERE D_E_L_E_T_ = ' ' "
    cQuery += "   AND ZV_DTFAT   = '" + DTOS(dAmanha) + "' "
    cQuery += " ORDER BY ZV_PEDIDO "
    cAlias := MPSysOpenQuery(cQuery)

    While !(cAlias)->(Eof())
        oExcel:AddRow("Carteira", "SZV", { ;
            (cAlias)->ZV_PEDIDO,        ;
            STOD((cAlias)->ZV_DTFAT),   ;
            (cAlias)->ZV_TOTAL          ;
        })
        nVlrCart += (cAlias)->ZV_TOTAL
        (cAlias)->(DbSkip())
    End  // While SZV
    (cAlias)->(DbCloseArea())

    oExcel:AddRow("Carteira", "SZV", {"TOTAL", CtoD("  /  /  "), nVlrCart})

    oExcel:Activate()
    oExcel:GetXMLFile(cFullNome)
    FreeObj(oExcel) 

Return

//--------------------------------------------------------------------
// MontaColunasMATA460
// Cria as 48 colunas que espelham o browse da MATA460A.
// Tipos: 1=String  2=N�mero  3=Data
//--------------------------------------------------------------------
Static Function MontaColunasMATA460(oExcel, cAba, cTabela)

    // --- Identifica��o ---
    oExcel:AddColumn(cAba, cTabela, "Filial",       1, 1)   //  1
    oExcel:AddColumn(cAba, cTabela, "Pedido",       1, 1)   //  2
    oExcel:AddColumn(cAba, cTabela, "Item",         1, 1)   //  3
    oExcel:AddColumn(cAba, cTabela, "Cliente",      1, 1)   //  4
    oExcel:AddColumn(cAba, cTabela, "Loja",         1, 1)   //  5
    oExcel:AddColumn(cAba, cTabela, "Nome Cliente", 1, 1)   //  6
    oExcel:AddColumn(cAba, cTabela, "Cond. Pgto",   1, 1)   //  7
    
    // --- Campos Adicionados ---
    oExcel:AddColumn(cAba, cTabela, "Tipo Pedido",  1, 1)   //  8 (C9_XTIPO)
    oExcel:AddColumn(cAba, cTabela, "Transp.",      1, 1)   //  9 (C9_XTRANSP)
    oExcel:AddColumn(cAba, cTabela, "Nome Transp.", 1, 1)   // 10 (C9_XNTRANS)
    oExcel:AddColumn(cAba, cTabela, "Status",       1, 1)   // 11 (C9_XSTATUS)

    // --- Valores ---
    oExcel:AddColumn(cAba, cTabela, "Produto",      1, 1)   // 12
    oExcel:AddColumn(cAba, cTabela, "Qt Liberada",  1, 2)   // 13
    oExcel:AddColumn(cAba, cTabela, "Prc Venda",    1, 2)   // 14
    oExcel:AddColumn(cAba, cTabela, "Vlr Total",    1, 2)   // 15 (C9_XVLTOT)

    // --- Dados Fiscais / Libera��o ---
    oExcel:AddColumn(cAba, cTabela, "Nota Fiscal",  1, 1)   // 16
    oExcel:AddColumn(cAba, cTabela, "Serie NF",     1, 1)   // 17
    oExcel:AddColumn(cAba, cTabela, "Dt Liberacao", 1, 3)   // 18  C9_DATALIB
    oExcel:AddColumn(cAba, cTabela, "Sequencia",    1, 1)   // 19
    oExcel:AddColumn(cAba, cTabela, "Dt p/Fatur",   1, 3)   // 20  C9_CRVENT (customizado)
    oExcel:AddColumn(cAba, cTabela, "Grupo",        1, 1)   // 21
    oExcel:AddColumn(cAba, cTabela, "Agreg. Liber", 1, 1)   // 22  C9_AGREG  (nativo)
    oExcel:AddColumn(cAba, cTabela, "Item Remito",  1, 1)   // 23
    oExcel:AddColumn(cAba, cTabela, "N. Remito",    1, 1)   // 24

    // --- Log�stica / Armaz�m ---
    oExcel:AddColumn(cAba, cTabela, "Armazem",       1, 1)  // 25
    oExcel:AddColumn(cAba, cTabela, "Lote",          1, 1)  // 26  C9_LOTECTL (nativo)
    oExcel:AddColumn(cAba, cTabela, "Carga",         1, 1)  // 27
    oExcel:AddColumn(cAba, cTabela, "Seq Carga",     1, 1)  // 28
    oExcel:AddColumn(cAba, cTabela, "Seq Entrega",   1, 1)  // 29
    oExcel:AddColumn(cAba, cTabela, "Servico",       1, 1)  // 30
    oExcel:AddColumn(cAba, cTabela, "End. Padrao",   1, 1)  // 31
    oExcel:AddColumn(cAba, cTabela, "Estr. Fisica",  1, 1)  // 32  C9_TPESTR (nativo)
    oExcel:AddColumn(cAba, cTabela, "Qt Liberada 2", 1, 2)  // 33
    oExcel:AddColumn(cAba, cTabela, "Ret. Operacao", 1, 1)  // 34
    oExcel:AddColumn(cAba, cTabela, "Seq. Empenho",  1, 1)  // 35  C9_TRT (nativo)
    oExcel:AddColumn(cAba, cTabela, "Dt Entrega",    1, 3)  // 36  C6_ENTREG (da SC6)

    // --- Bloqueios nativos ---
    oExcel:AddColumn(cAba, cTabela, "Bloq.Credi",   1, 1)   // 37  C9_BLCRED
    oExcel:AddColumn(cAba, cTabela, "Bloq.Estoq",   1, 1)   // 38  C9_BLEST
    oExcel:AddColumn(cAba, cTabela, "Bloq WMS",     1, 1)   // 39  C9_BLWMS
    oExcel:AddColumn(cAba, cTabela, "Inf.Bloqueio", 1, 1)   // 40  C9_BLINF  (nativo)
    oExcel:AddColumn(cAba, cTabela, "Bloq TMS",     1, 1)   // 41  C9_BLTMS

    // --- Bloqueios customizados do cliente ---
    oExcel:AddColumn(cAba, cTabela, "Bloq Pag",     1, 1)   // 42  C9_BLQPAG
    oExcel:AddColumn(cAba, cTabela, "Bloq Frete",   1, 1)   // 43  C9_BLQFRT
    oExcel:AddColumn(cAba, cTabela, "Blq Transp",   1, 1)   // 44  C9_BLQTRAN
    oExcel:AddColumn(cAba, cTabela, "Blq Desc",     1, 1)   // 45  C9_BLQDESC
    oExcel:AddColumn(cAba, cTabela, "Blq Validade", 1, 1)   // 46  C9_BLQDTV
    oExcel:AddColumn(cAba, cTabela, "Blq PVTO",     1, 1)   // 47  C9_XBLPVTO
    oExcel:AddColumn(cAba, cTabela, "Blq RC",       1, 1)   // 48  C9_XBLQRC

Return


/*=================================================================
   xEnvMail � Envio de e-mail via TMailManager (SMTP)
==================================================================*/
/*=================================================================
Autor: Vinicius N. de Oliveira
Data: 04/12/2025
Consultoria: TecSistem Consultoria em Sistemas de Informacao
Uso: Calibre
Info: Envio de e-mail 
*==================================================================*/
Static Function xEnvMail(cArquivo,cEmail,cAssunto,cCorpo)

	Local cAssuntoFinal := If(Empty(cAssunto), "Relatorio", cAssunto)
	Local cBodyFinal    := If(Empty(cCorpo), "Segue em anexo relatorio.", cCorpo)
	Local lMailAuth	:= GetMV("MV_RELAUTH",.F.,.T.) //Autenticacao com server SMTP
	Local nPortSMTP := 587
	Local nTimeout  := GetMV("MV_RELTIME")
	Local xRet
	Local oServer	
	Local oMessage

    Private cMailConta  := Alltrim(GetMV("MV_RELACNT"))
	Private cMailServer := AllTrim(GetMV("MV_RELSERV"))
	Private cMailSenha  := Alltrim(GetMV("MV_RELPSW"))
	Private nPosPort    := AT(":", cMailServer)

	If nPosPort > 0
		nPortSMTP   := Val(SubStr(cMailServer, nPosPort+1))
		cMailServer := AllTrim(SubStr(cMailServer, 1, nPosPort-1))
	EndIf

	If Empty(cArquivo) .Or. Empty(cEmail)
		Return .F.
	EndIf

	oServer := TMailManager():New()
	oServer:SetUseTLS(.T.)
	oServer:SetUseSSL(.T.)

    xRet := oServer:Init( "", cMailServer, Alltrim(GetMV("MV_RELFROM",.F.,"no-reply@carvalhaes.net")), cMailSenha,, nPortSMTP )

	If xRet <> 0
		MsgAlert("O servidor SMTP nao foi inicializado: " + oServer:GetErrorString( xRet ))
		Return .F.
	EndIf

	xRet := oServer:SetSMTPTimeout(nTimeout)

	If xRet <> 0
		MsgAlert("Tempo limite para " + cValToChar( nTimeout ))
	EndIf

	xRet := oServer:SMTPConnect()

	If xRet <> 0
		MsgAlert("Nao foi possivel conectar ao server SMTP: " + oServer:GetErrorString( xRet ))
		Return .F.
	EndIf

	If lMailAuth

		xRet := oServer:SmtpAuth( cMailConta, cMailSenha )

		If xRet <> 0
			MsgAlert("Nao foi possivel autenticar no server SMTP: " + oServer:GetErrorString( xRet ))
			oServer:SMTPDisconnect()
			Return .F.
		EndIf

	EndIf
	
	oMessage := TMailMessage():New()

	oMessage:Clear()

	oMessage:cDate	  := cValToChar(Date())
	oMessage:cFrom 	  := AllTrim(GetMV("MV_RELFROM",.F.,"no-reply@carvalhaes.net"))
	oMessage:cTo 	  := cEmail
	oMessage:cSubject := cAssuntoFinal
	oMessage:cBody 	  := cBodyFinal

	xRet := oMessage:AttachFile(cArquivo)
	
	If xRet < 0
		MsgAlert("Nao foi possivel anexar o arquivo: " + cArquivo)
	EndIf

	xRet := oMessage:Send( oServer )

	If xRet <> 0
		MsgAlert("Nao foi possivel enviar o relatorio: " + oServer:GetErrorString( xRet ))
	Else
		//MsgAlert("Relatorio enviado com sucesso...")
	EndIf

	xRet := oServer:SMTPDisconnect()

	If xRet <> 0
		MsgAlert("Nao foi possivel desconectar o servidor SMTP: " + oServer:GetErrorString( xRet ))
	Else
		//MsgAlert("["+DToc(dDatabase)+"-"+Time()+"] Server desconectado com sucesso...")
	EndIf

Return .T.

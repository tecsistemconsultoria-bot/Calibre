#Include "Protheus.ch"  
#Include "Rwmake.ch"
#Include "TopConn.ch"                               
#Include "TBIConn.ch" 

/***********************************************************************
Autor: Vinicius N. de Oliveira
Data: 25/08/2026
Uso: Calibre
Tipo: Atualiza��es
Rotina: Espec�fica
Fun��o: GVLDESCK
Info: Atualiza��o do Pre�o no or�amento tabela SCK
************************************************************************/
User Function GVLDESCK()

	Local aArea := GetArea()
	Local nRet  := 0  

	nRet := xGvlDeSCK()
	
	RestArea(aArea)

Return(nRet)

/*=================================================================
Autor: Vinicius N. de Oliveira
Data: 25/08/2026
Uso: Calibre
Info: Atualiza��o do Pre�o no or�amento tabela SCK
*==================================================================*/
Static Function xGvlDeSCK()

	Local nRet     := 0      
	Local nTotTab  := 0
	Local nTotVlVe := 0                                                                   

	If TMP1->CK_XPRCTAB >=TMP1->CK_PRCVEN   

		If TMP1->CK_QTDVEN == 0  
		
			nTotTab := 1 * TMP1->CK_XPRCTAB
			
		Else 
			
			nTotTab := TMP1->CK_QTDVEN * TMP1->CK_XPRCTAB
		
		Endif 

		If TMP1->CK_VALOR == 0   
			nTotVlVe := 1 * TMP1->CK_PRCVEN	
		Else                                
			nTotVlVe := TMP1->CK_QTDVEN * TMP1->CK_PRCVEN
		EndIf

		nRet := nTotTab - nTotVlVe

	Else 
		
		nRet := 0
		
	Endif 
 
	SYSREFRESH()
	GetDRefresh()

Return(nRet)

/*=================================================================
Autor: Ot�vio Barreiro
Data: 26/08/2026
Uso:  Calibre
Fun��o: QTDVEN507
Info: Gatilho Da CK_QTDVEN  Sequencia 507	
*==================================================================*/
User Function QTDVEN507()


Return(U_xCalcPrc(TMP1->CK_PRUNIT,M->CJ_CLIENTE,M->CJ_LOJA,TMP1->CK_TES,M->CJ_TIPOCLI,AllTrim(TMP1->CK_PRODUTO)))

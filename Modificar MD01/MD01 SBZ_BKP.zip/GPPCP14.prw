/*
�����������������������������������������������������������������������������
�����������������������������������������������������������������������������
�������������������������������������������������������������������������ͻ��
���Programa  �GPPCP14      �Autor  �LUCIANO          � Data �  28/07/19   ���
�������������������������������������������������������������������������͹��
���Desc.     �   Tela consulta r�pida MD01                                ���
���          �   Apoio para o relat�rio de cobertura do MRP               ���
�������������������������������������������������������������������������͹��
���Uso       � AP                                                         ���
�������������������������������������������������������������������������ͼ��
�����������������������������������������������������������������������������
�� 23/08/20 - ACRESCIMO DO CAMPO BZ_ZZPLANER E ABATER LOCAL NC             ��
�� 29/11/21 - TRATATIVA PARA SD4 COM O D4_COD XTIPO == "PA"                ��
�����������������������������������������������������������������������������
*/

#INCLUDE "PROTHEUS.CH"
#include "tbiconn.ch"

User Function GPPCP14()
	
Private oLbx2    := Nil
Private oLbx3    := Nil
Private bLbx3    := {}
Private aLbx3    := {"Material","Data","Doc Entrada","Qtde Entrada","Doc Saida","Qtde Saida","Saldo","Status ","Semana"}	

Private aItens2   := {'','',0,'',0,0,'',''}
Private aItens3   := {'','','',0,'',0,0,'',''}

Private oTimer
Private CCOD     := SPACE(15)

PRIVATE CTMD01   := TIME()

Private nMilissegundos := 0 //EXEPLO 60000 // Disparo ser� de 1 em 1 segundos

oDlg1 := MSDialog():New( 092,232,700,1487,"Tela de consulta r�pida MD01 - "+DTOC(DDATABASE)+" - "+CTMD01,,,.F.,,,,,,.T.,,,.T. )

odlg1:CTOOLTIP := "consulta tela MD01 materiais"

PRIVATE XDESC    := SPACE(40)    
PRIVATE XTIPO    := SPACE(2)
PRIVATE XGRUPO   := SPACE(5)    
PRIVATE XQE      := 0
PRIVATE XPE      := 0
PRIVATE xESTSEG  := 0
PRIVATE xESTMULT := 0
PRIVATE xESTMIN  := 0
PRIVATE xESTATU  := 0    
PRIVATE xEST55   := 0   
PRIVATE xCONMED  := 0  
PRIVATE xCONMES  := 0  
PRIVATE xCUSTO   := 0
PRIVATE xTIPE    := ""
PRIVATE dDATAP   := CTOD("  /  /  ")   
     
@ 005,005 SAY "Item:" SIZE 150, 20 OF oDlg1 PIXEL
@ 0.2,003 MSGET CCOD F3 "SB1" VALID FOKSB1()
@ 017,005 SAY "Descri��o: "+XDESC SIZE 150, 20 OF oDlg1 PIXEL
@ 005,300 SAY "Qtde Embalagem:" SIZE 150, 20 OF oDlg1 PIXEL
@ 005,360 SAY TRANSFORM(xQE,"@E 999,999.999") SIZE 150, 20 OF oDlg1 PIXEL    
@ 005,180 SAY "Tipo  : " SIZE 150, 20 OF oDlg1 PIXEL    
@ 017,180 SAY "Grupo : " SIZE 150, 20 OF oDlg1 PIXEL 
@ 0.2,025 MSGET XTIPO F3 "02" VALID A010Tipo() WHEN .F.                                                                                                                     
@ 1.1,025 MSGET XGRUPO F3 "SBM" VALID A010Grupo() WHEN .F.
@ 017,240 SAY "Lead Time: "+ALLTRIM(TRANSFORM(xPE,"@E 999,999"))+" "+xTIPE  SIZE 150, 20 OF oDlg1 PIXEL
@ 005,400 SAY "Estoque Seguran�a: " SIZE 150, 20 OF oDlg1 PIXEL
@ 005,460 SAY TRANSFORM(xESTSEG,"@E 999,999.999") SIZE 150, 20 OF oDlg1 PIXEL
@ 005,520 SAY "Lote M�nimo:" SIZE 150, 20 OF oDlg1 PIXEL
@ 005,560 SAY TRANSFORM(xESTMIN,"@E 999,999.999") SIZE 150, 20 OF oDlg1 PIXEL
@ 015,300 SAY "Estoque Dispon�vel:" SIZE 150, 20 OF oDlg1 PIXEL
@ 015,360 SAY TRANSFORM(xESTATU,"@E 999,999.999") SIZE 150, 20 OF oDlg1 PIXEL
@ 015,400 SAY "Estoque NC:" SIZE 150, 20 OF oDlg1 PIXEL
@ 015,460 SAY TRANSFORM(xEST55,"@E 999,999.999") SIZE 150, 20 OF oDlg1 PIXEl
@ 015,520 SAY "Lote Economico:" SIZE 150, 20 OF oDlg1 PIXEL
@ 015,560 SAY TRANSFORM(xESTMULT,"@E 999,999.999") SIZE 150, 20 OF oDlg1 PIXEL
@ 026,120 SAY "Consumo m�dio mensal �ltimos 12 meses: " SIZE 150, 20 OF oDlg1 PIXEL
@ 026,220 SAY TRANSFORM(xCONMED,"@E 99,999,999.999") SIZE 150, 20 OF oDlg1 PIXEL
@ 026,300 SAY "Qtde utilizada no �ltimo m�s: " SIZE 150, 20 OF oDlg1 PIXEL
@ 026,380 SAY TRANSFORM(xCONMES,"@E 99,999,999.999") SIZE 150, 20 OF oDlg1 PIXEL 
@ 026,480 SAY "Valor do custo m�dio do item: " SIZE 150, 20 OF oDlg1 PIXEL
@ 026,560 SAY TRANSFORM(xCUSTO,"@E 999,999.999") SIZE 150, 20 OF oDlg1 PIXEL 
@ 035,010 LISTBOX oLbx3 FIELDS HEADER "" SIZE 610,250  OF oDlg1 PIXEL CENTERED
oLbx3:aColumns  := aLbx3
oLbx3:aHeaders  := oLbx3:aColumns
oLbx3:lUseDefaultColors := .F.      

ItenMD01(1)

//oBtn1 := TButton():New( 003,530,"Fechar    ",oDlg1,{||oDlg1:End()},037,012,,,,.T.,,"",,,,.F. )
oBtn2 := TButton():New( 003,125,"Executar  ",oDlg1,{||itenMD01(2)},037,012,,,,.T.,,"",,,,.F. )
oBtn3 := TButton():New( 003,590,"Refresh...",oDlg1,{||reftime()},030,012,,,,.T.,,"",,,,.F. )

ACTIVATE MSDIALOG oDlg1 CENTERED
    
Return    

static function reftime()            
 
  PRIVATE nGetTime := 0

  DEFINE MSDIALOG oDlgT TITLE "Tempo de Refresh" FROM 000, 000  TO 100, 230 COLORS 0, 16777215 PIXEL

  @ 013, 068 MSGET oGet1 VAR nGetTime SIZE 031, 010 OF oDlgT PICTURE "@E 9999" COLORS 16711680, 16777215 PIXEL
  @ 013, 010 SAY oSay1 PROMPT "Tempo (Minutos):" SIZE 054, 011 OF oDlgT COLORS 0, 16777215 PIXEL
  DEFINE SBUTTON oSButton1 FROM 031, 044 TYPE 01 OF oDlgT ENABLE ACTION FOKTMP()

  ACTIVATE MSDIALOG oDlgT CENTERED

return

STATIC FUNCTION FOKTMP()

nMilissegundos := nGetTime * 60000

if nMilissegundos == 0 
  IF TYPE("oTimer") == "O"
    ALERT("Refresh desativado...") 
    oTimer:lActive := .F.   
  ENDIF
else  
  alert("Timer ativado para atualizar a cada: "+alltrim(str(nGetTime))+" Minuto(s)")
  oTimer := TTimer():New(nMilissegundos, {|| FOK() }, oDlg1 )
  oTimer:Activate()
endif   

oDlgT:end()

return

static function fok()

//if msgyesno("Atualizar tela ?")
   ItenMD01(2)
//endif

return

STATIC FUNCTION FPLAN()

local AA:= .T.

RETURN AA

STATIC FUNCTION FOKSB1()
   
   XQE      := 0
   XPE      := 0
   xESTSEG  := 0
   xESTMULT := 0
   xESTMIN  := 0
   xEST55   := 0
   xESTATU  := 0   
   xCONMED  := 0  
   xCONMES  := 0  
   xCUSTO   := 0
   xTIPE    := ""
   dDATAP   := CTOD("  / /  ")
   
   IF EMPTY(CCOD)
      
      XDESC    := ""   
      XTIPO    := SPACE(2)  
      XGRUPO   := SPACE(5)
      XQE      := 0
      XPE      := 0
      xESTSEG  := 0
      xESTMULT := 0
      xESTMIN  := 0
      xEST55   := 0
      xESTATU  := 0   
      xCONMED  := 0  
      xCONMES  := 0  
      xCUSTO   := 0
      xTIPE    := ""
      dDATAP   := CTOD("  / /  ")
      
      RETURN .T.    
      
   ENDIF         

   DBSELECTAREA("SB1")
   DBSETORDER(1)
   DBSEEK(XFILIAL("SB1")+CCOD)
   IF FOUND()   
   
      PRIVATE XLOCPAD := ""
      XLOCPAD := SB1->B1_LOCPAD
   
      DBSELECTAREA("SBZ")
      DBSETORDER(1)
      DBSEEK(XFILIAL("SBZ")+ALLTRIM(CCOD))  
      IF FOUND()
         XLOCPAD := SBZ->BZ_LOCPAD
      ENDIF
   
      cQUERY := " SELECT B9_DATA, B9_COD, B9_LOCAL, B9_CM1  FROM "+RETSQLNAME("SB9")
      cQUERY += " WHERE B9_CM1 > 0 AND D_E_L_E_T_ <> '*' AND B9_FILIAL = '"+XFILIAL("SB9")+"'"
      cQUERY += " AND B9_COD = '"+CCOD+"'" 
      IF !EMPTY(XLOCPAD)
         cQUERY += " AND B9_LOCAL = '"+XLOCPAD+"'"
      ENDIF
      cQUERY += " GROUP BY B9_DATA, B9_COD, B9_LOCAL, B9_CM1 "     
      cQUERY += " ORDER BY B9_DATA DESC "
      cQUERY := ChangeQuery(cQUERY)
      dbUseArea(.T., "TOPCONN", TCGENQRY(,,CQUERY), "TRBSB9", .F., .T.)

      DBSELECTAREA("TRBSB9")
      DBGOTOP()
      IF !EOF() .AND. !BOF()
         xCUSTO := TRBSB9->B9_CM1
      ENDIF
      DBSELECTAREA("TRBSB9")
      DBCLOSEAREA("TRBSB9") 
   
      xCONMED  := 0   
   
      cDTINI := substr(dtos(MonthSub(dDatabase,12)),1,6)+"01"
      cDTFIM := dtos(ddatabase)
   
      cQUERY := " SELECT ROUND(SUM(D3_QUANT)/12,3) AS QTDE FROM "+RETSQLNAME("SD3")
      cQUERY += " WHERE D3_COD = '"+CCOD+"'"
      cQUERY += " AND D_E_L_E_T_ <> '*' "
      cQUERY += " AND D3_ESTORNO <> 'S' "
      cQUERY += " AND ( D3_CF = 'RE0' OR D3_CF = 'RE1' ) "       
      cQUERY += " AND D3_FILIAL = '"+XFILIAL("SD3")+"'"
      cQUERY += " AND D3_EMISSAO >= '"+cDTINI+"' AND D3_EMISSAO <= '"+cDTFIM+"'"
      cQUERY := ChangeQuery(cQUERY)
      dbUseArea(.T., "TOPCONN", TCGENQRY(,,CQUERY), "TRBSD3", .F., .T.)

      DBSELECTAREA("TRBSD3")
      DBGOTOP()
      IF !EOF() .AND. !BOF()
         xCONMED := TRBSD3->QTDE
      ENDIF
      DBSELECTAREA("TRBSD3")
      DBCLOSEAREA("TRBSD3") 
   
      xCONMES  := 0  
   
      cDTINI := substr(dtos(MonthSub(dDatabase,1)),1,6)+"01"
      cDTFIM := dtos(lastday(MonthSub(dDatabase,1)))
   
      cQUERY := " SELECT ROUND(SUM(D3_QUANT),3) AS QTDE FROM "+RETSQLNAME("SD3")
      cQUERY += " WHERE D3_COD = '"+CCOD+"'"
      cQUERY += " AND D_E_L_E_T_ <> '*' "
      cQUERY += " AND D3_ESTORNO <> 'S' "
      cQUERY += " AND ( D3_CF = 'RE0' OR D3_CF = 'RE1' ) "       
      cQUERY += " AND D3_FILIAL = '"+XFILIAL("SD3")+"'"
      cQUERY += " AND D3_EMISSAO >= '"+cDTINI+"' AND D3_EMISSAO <= '"+cDTFIM+"'"
      cQUERY := ChangeQuery(cQUERY)
      dbUseArea(.T., "TOPCONN", TCGENQRY(,,CQUERY), "TRBSD3", .F., .T.)

      DBSELECTAREA("TRBSD3")
      DBGOTOP()
      IF !EOF() .AND. !BOF()
         xCONMES := TRBSD3->QTDE
      ENDIF
      DBSELECTAREA("TRBSD3")
      DBCLOSEAREA("TRBSD3") 
   
      XDESC    := SUBSTR(SB1->B1_DESC,1,40)   
      XTIPO    := SB1->B1_TIPO        
      XGRUPO   := SB1->B1_GRUPO
      xTIPE    := ""
      
	  DBSELECTAREA("SBZ")
	  DBSETORDER(1)
	  DBSEEK(XFILIAL("SBZ")+SB1->B1_COD)
	  IF FOUND()
   	   XQE      := SBZ->BZ_QE
         XPE      := SBZ->BZ_PE
         xESTSEG  := SBZ->BZ_ESTSEG
         xESTMULT := SBZ->BZ_LE
         xESTMIN  := SBZ->BZ_LM
         IF SBZ->BZ_TIPE == "H"
            xTIPE  := "Horas"
         ENDIF
         IF SBZ->BZ_TIPE == "D"
           xTIPE  := "Dias"   
           IF SBZ->BZ_PE > 0
             dDATAP := Datavalida(DaySum(dDatabase,SBZ->BZ_PE),.F.) 
           ENDIF 
         ENDIF
         IF SBZ->BZ_TIPE == "S"
           xTIPE  := "Semana"  
           IF SBZ->BZ_PE > 0
             dDATAP := Datavalida(DaySum(dDatabase,(SBZ->BZ_PE*7)),.F.)
           ENDIF
         ENDIF
         IF SBZ->BZ_TIPE == "M"
           xTIPE  := "Mes"    
           IF SBZ->BZ_PE > 0
              dDATAP := Datavalida(MonthSum(dDatabase,SBZ->BZ_PE),.F.) 
           ENDIF 
         ENDIF
         IF SBZ->BZ_TIPE == "A"
           xTIPE  := "Ano"  
         ENDIF                          
	  ELSE  
   	   XQE      := SB1->B1_QE
         XPE      := SB1->B1_PE
         xESTSEG  := SB1->B1_ESTSEG
         xESTMULT := SB1->B1_LE
         xESTMIN  := SB1->B1_LM   
         IF SB1->B1_TIPE == "H"
            xTIPE  := "Horas"
         ENDIF
         IF SB1->B1_TIPE == "D"
            xTIPE  := "Dias"   
            IF SB1->B1_PE > 0
               dDATAP := Datavalida(DaySum(dDatabase,SB1->B1_PE),.F.) 
            ENDIF 
         ENDIF
         IF SB1->B1_TIPE == "S"
            xTIPE  := "Semana"  
            IF SB1->B1_PE > 0
               dDATAP := Datavalida(DaySum(dDatabase,(SB1->B1_PE*7)),.F.)
            ENDIF
         ENDIF
         IF SB1->B1_TIPE == "M"
           xTIPE  := "Mes"    
           IF SB1->B1_PE > 0
              dDATAP := Datavalida(MonthSum(dDatabase,SB1->B1_PE),.F.) 
           ENDIF 
         ENDIF
         IF SB1->B1_TIPE == "A"
           xTIPE  := "Ano"  
         ENDIF                             
	  ENDIF
	  
	  DBSELECTAREA("SB2")
      DBSETORDER(1)
      DBSEEK(XFILIAL("SB2")+SB1->B1_COD+"NC")
      IF FOUND()
         xEST55 := SB2->B2_QATU
      ENDIF  
      DBSELECTAREA("SB2")
      DBSETORDER(1)
      DBSEEK(XFILIAL("SB2")+SB1->B1_COD)  
      DO WHILE !EOF() .AND. SB2->B2_FILIAL == XFILIAL("SB2") .AND. SB1->B1_COD == SB2->B2_COD 
         IF ALLTRIM(SB2->B2_LOCAL) <> "NC" //NAO CONSIDERAR O ESTOQUE NAO CONFORME (NC) 23-08-20 LUCIANO
		    xESTATU += SB2->B2_QATU
         ENDIF
		 DBSKIP()
      ENDDO      
      AA := .T. 
   
   ELSE
   
      ALERT("Produto nao localizado !")
      AA := .F.   
  
   ENDIF
   
    
RETURN AA

STATIC Function ItenMD01(xtip)
  
  CTMD01          := TIME()           
  odlg1:CTITLE    := "Tela de consulta r�pida MD01 - "+DTOC(DDATABASE)+" - "+CTMD01   
  odlg1:CCAPTION  := "Tela de consulta r�pida MD01 - "+DTOC(DDATABASE)+" - "+CTMD01 
  oDlg1:REFRESH()    
  
  processa({ || fokpro(xtip) })
    
return


static function fokpro(xtip)

LOCAL QUERY  := {}     
LOCAL XSALDO := xESTATU

LOCAL XRECSB1 := SB1->(RECNO())

aItens2 := {}
aItens3 := {}
 
if xtip == 1
   
   AAdd(aItens2,{dDatabase,;
	     "",;
         0,;
         "",;
         0,;
	     0,;
	     "",;
	   	 ""})
   oLbx2 := TCBrowse():New(035,010,610,250,,,,oDlg1,,,,,,,,,,,,.F.,,.T.,,.F.,,,)                
   oLbx2:AddColumn(TCColumn():New("Data"   , {|| aItens2[oLbx2:nAt,01]},"",,,"CENTER", 010,.F.,.F.,,,,.F., ) ) 
   oLbx2:AddColumn(TCColumn():New("Doc Entrada" , {|| aItens2[oLbx2:nAt,02]},"@!",,,"LEFT", 040,.F.,.F.,,{|| .F. },,.F., ) )
   oLbx2:AddColumn(TCColumn():New("Qtde Entrada"   , {|| aItens2[oLbx2:nAt,03]},"@!",,,"RIGHT", 010,.F.,.F.,,,,.F., ) )
   oLbx2:AddColumn(TCColumn():New("Doc Saida", {|| aItens2[oLbx2:nAt,04]},"@!",,,"LEFT", 050,.F.,.F.,,,,.F., ) )
   oLbx2:AddColumn(TCColumn():New("Qtde Saida" , {|| aItens2[oLbx2:nAt,05]},"@!",,,"RIGHT", 040,.F.,.F.,,{|| .F. },,.F., ) )
   oLbx2:AddColumn(TCColumn():New("Saldo"   , {|| aItens2[oLbx2:nAt,06]},"@!",,,"RIGHT", 010,.F.,.F.,,,,.F., ) )
   oLbx2:AddColumn(TCColumn():New("Status", {|| aItens2[oLbx2:nAt,07]},"@!",,,"CENTER", 050,.F.,.F.,,,,.F., ) )      
   oLbx2:AddColumn(TCColumn():New("Semana", {|| aItens2[oLbx2:nAt,08]},"@!",,,"LEFT", 050,.F.,.F.,,,,.F., ) )      

   oLbx2:SetArray(aItens2)
   oLbx2:bWhen := { || Len(aItens2) > 0 }
   oLbx2:Show()
   oLbx2:Refresh()

   AAdd(aItens3,{"",dDatabase,;
	     "",;
         0,;
         "",;
         0,;
	     0,;
	     "",;
	   	 ""})

   oLbx3:SetArray(aItens3)
   oLbx3:bLine:= {|| { aItens3[oLbx2:nAt,1],;
   aItens3[oLbx3:nAt,2],;
   aItens3[oLbx3:nAt,3],;
   aItens3[oLbx3:nAt,4],;  
   aItens3[oLbx3:nAt,5],;   
   aItens3[oLbx3:nAt,6],;
   aItens3[oLbx3:nAt,7],; 
   aItens3[oLbx3:nAt,8],; 
   aItens3[oLbx3:nAt,9]}}
   oLbx3:hide()
   oLbx3:Refresh()
   
   return
   
endif  

IF XTIPO <> "PA" .AND. XTIPO <> "PI" .AND. XTIPO <> "PV"

   cQUERY := " SELECT C2_DATPRI AS DTINI, C2_PRODUTO AS PAI , '' AS PC, SUBSTRING(D4_OP,1,6) AS NUMOP, 0 AS EQTDE, D4_QUANT AS SQTDE, D4_COD AS MATERIAL, " 
   cQUERY += " C2_TPOP AS STATOP, 'S' AS TIPO FROM "+RETSQLNAME("SD4")+", "+RETSQLNAME("SC2")+", "+RETSQLNAME("SB1")
   cQUERY += " WHERE D4_FILIAL = '"+XFILIAL("SD4")+"' AND "+RETSQLNAME("SD4")+".D_E_L_E_T_ <> '*' AND "
   cQUERY += RETSQLNAME("SC2")+".D_E_L_E_T_ <> '*' AND "+RETSQLNAME("SB1")+".D_E_L_E_T_ <> '*' "
   cQUERY += " AND B1_COD = D4_COD AND D4_OP = C2_NUM+C2_ITEM+C2_SEQUEN "
   CQUERY += " AND B1_FILIAL = '"+XFILIAL("SB1")+"' AND C2_FILIAL = '"+XFILIAL("SC2")+"'"
   IF !EMPTY(CCOD)
      cQUERY += " AND B1_COD = '"+ALLTRIM(CCOD)+"' " 
   ENDIF
   IF !EMPTY(XTIPO)
      cQUERY += " AND B1_TIPO = '"+ALLTRIM(XTIPO)+"' " 
   ENDIF

   cQUERY += " AND D4_QUANT > 0 "
   cQUERY += " UNION ALL "
   cQUERY += " SELECT C7_DATPRF AS DTINI, '' AS PAI , (C7_TPOP+'-'+C7_NUM+'-'+C7_ITEM) AS PC, '' AS NUMOP, C7_QUANT - C7_QUJE AS EQTDE, 0 AS SQTDE, C7_PRODUTO AS MATERIAL, "
   cQUERY += " C7_TPOP AS STATOP, 'E' AS TIPO FROM "+RETSQLNAME("SC7")+", "+RETSQLNAME("SB1")
   cQUERY += " WHERE C7_RESIDUO = '' AND C7_QUANT-C7_QUJE > 0 AND "+RETSQLNAME("SC7")+".D_E_L_E_T_ <> '*' "  
   cQUERY += " AND "+RETSQLNAME("SB1")+".D_E_L_E_T_ <> '*' "
   cQUERY += " AND C7_PRODUTO = B1_COD "
   CQUERY += " AND B1_FILIAL = '"+XFILIAL("SB1")+"' AND C7_FILIAL = '"+XFILIAL("SC7")+"' AND C7_NUMIMP = '' "
   IF !EMPTY(CCOD)
      cQUERY += " AND C7_PRODUTO = '"+ALLTRIM(CCOD)+"'"
   ENDIF
   IF !EMPTY(XTIPO)
      cQUERY += " AND B1_TIPO = '"+ALLTRIM(XTIPO)+"' " 
   ENDIF
   IF !EMPTY(XGRUPO)
      cQUERY += " AND B1_GRUPO = '"+ALLTRIM(XGRUPO)+"' " 
   ENDIF

   cQUERY += " ORDER BY MATERIAL, DTINI, TIPO "
   cQUERY := ChangeQuery(cQUERY)
   dbUseArea(.T., "TOPCONN", TCGENQRY(,,CQUERY), "TRBSC2", .F., .T.)
   TCSetField( "TRBSC2", "DTINI", "D", 8, 0 )

ELSE
   
   //entra pela op
   
   IF XTIPO == "PA" .OR. XTIPO == "PI" .OR. XTIPO == "PV"  
   
      cQUERY := " SELECT C2_DATPRF AS DTINI, C2_PRODUTO AS PAI , (C2_TPOP+'-'+C2_NUM) AS PC, '' AS NUMOP, C2_QUANT - C2_QUJE AS EQTDE, 0 AS SQTDE, C2_PRODUTO AS MATERIAL, " 
      cQUERY += " C2_TPOP AS STATOP, 'E' AS TIPO FROM "+RETSQLNAME("SC2")+", "+RETSQLNAME("SB1")
      cQUERY += " WHERE "
      cQUERY += RETSQLNAME("SC2")+".D_E_L_E_T_ <> '*' AND "+RETSQLNAME("SB1")+".D_E_L_E_T_ <> '*' "
      cQUERY += " AND B1_COD = C2_PRODUTO "
      cQUERY += " AND B1_FILIAL = '"+XFILIAL("SB1")+"' AND C2_FILIAL = '"+XFILIAL("SC2")+"'"
      IF !EMPTY(CCOD)
         cQUERY += " AND B1_COD = '"+ALLTRIM(CCOD)+"' " 
      ENDIF
      IF !EMPTY(XTIPO)
         cQUERY += " AND B1_TIPO = '"+ALLTRIM(XTIPO)+"' " 
      ENDIF

      cQUERY += " AND C2_QUANT - C2_QUJE > 0 "
      cQUERY += " AND ( C2_DATRF > '"+DTOS(DDATABASE)+"' OR C2_DATRF = '' ) "
   ENDIF 
   
   IF XTIPO == "PA" .OR.  XTIPO == "PV"
   
      IF XTIPO == "PA"
         cQUERY += " UNION ALL "
         cQUERY += " SELECT C2_DATPRI AS DTINI, C2_PRODUTO AS PAI , '' AS PC, SUBSTRING(D4_OP,1,6) AS NUMOP, 0 AS EQTDE, D4_QUANT AS SQTDE, D4_COD AS MATERIAL, " 
         cQUERY += " C2_TPOP AS STATOP, 'S' AS TIPO FROM "+RETSQLNAME("SD4")+", "+RETSQLNAME("SC2")+", "+RETSQLNAME("SB1")
         cQUERY += " WHERE D4_FILIAL = '"+XFILIAL("SD4")+"' AND "+RETSQLNAME("SD4")+".D_E_L_E_T_ <> '*' AND "
         cQUERY += RETSQLNAME("SC2")+".D_E_L_E_T_ <> '*' AND "+RETSQLNAME("SB1")+".D_E_L_E_T_ <> '*' "
         cQUERY += " AND B1_COD = D4_COD AND D4_OP = C2_NUM+C2_ITEM+C2_SEQUEN "
         CQUERY += " AND B1_FILIAL = '"+XFILIAL("SB1")+"' AND C2_FILIAL = '"+XFILIAL("SC2")+"' "
         IF !EMPTY(CCOD)
            cQUERY += " AND B1_COD = '"+ALLTRIM(CCOD)+"' " 
         ENDIF
         IF !EMPTY(XTIPO)
            cQUERY += " AND B1_TIPO = '"+ALLTRIM(XTIPO)+"' " 
         ENDIF

         cQUERY += " AND D4_QUANT > 0 "
      ENDIF
  
      IF XTIPO == "PV"
         
         cQUERY += " UNION ALL "
         cQUERY += " SELECT C7_DATPRF AS DTINI, '' AS PAI , (C7_TPOP+'-'+C7_NUM+'-'+C7_ITEM) AS PC, '' AS NUMOP, C7_QUANT - C7_QUJE AS EQTDE, 0 AS SQTDE, C7_PRODUTO AS MATERIAL, "
         cQUERY += " C7_TPOP AS STATOP, 'E' AS TIPO FROM "+RETSQLNAME("SC7")+", "+RETSQLNAME("SB1")
         cQUERY += " WHERE C7_RESIDUO = '' AND C7_QUANT-C7_QUJE > 0 AND "+RETSQLNAME("SC7")+".D_E_L_E_T_ <> '*' "  
         cQUERY += " AND "+RETSQLNAME("SB1")+".D_E_L_E_T_ <> '*' "
         cQUERY += " AND C7_PRODUTO = B1_COD "
         CQUERY += " AND B1_FILIAL = '"+XFILIAL("SB1")+"' AND C7_FILIAL = '"+XFILIAL("SC7")+"' AND C7_NUMIMP = '' "
         IF !EMPTY(CCOD)
            cQUERY += " AND C7_PRODUTO = '"+ALLTRIM(CCOD)+"'"
         ENDIF
         IF !EMPTY(XTIPO)
            cQUERY += " AND B1_TIPO = '"+ALLTRIM(XTIPO)+"' " 
         ENDIF
         IF !EMPTY(XGRUPO)
            cQUERY += " AND B1_GRUPO = '"+ALLTRIM(XGRUPO)+"' " 
         ENDIF

      ENDIF

      cQUERY += " UNION ALL"   //C6_ENTREG
      cQUERY += " SELECT C6_ENTREG AS DTINI, '' AS PAI , '' AS PC, (C6_NUM+'-'+C6_ITEM+'-'+LTRIM(RTRIM(C6_PRODUTO))+'-'+LTRIM(RTRIM(C6_DESCRI))) AS NUMOP, 0 AS EQTDE, C6_QTDVEN - C6_QTDENT AS SQTDE, C6_PRODUTO AS MATERIAL, "
      cQUERY += " 'F' AS STATOP, 'S' AS TIPO FROM "+RETSQLNAME("SC6")+", "+RETSQLNAME("SB1")
      cQUERY += " WHERE C6_BLOQUEI = '' AND C6_BLQ <> 'R' AND C6_BLQ <> 'S' AND C6_QTDVEN-C6_QTDENT > 0 AND "+RETSQLNAME("SC6")+".D_E_L_E_T_ <> '*' "  
      cQUERY += " AND "+RETSQLNAME("SB1")+".D_E_L_E_T_ <> '*' "
      cQUERY += " AND C6_PRODUTO = B1_COD "
      CQUERY += " AND B1_FILIAL = '"+XFILIAL("SB1")+"' AND C6_FILIAL = '"+XFILIAL("SC6")+"' "
      IF !EMPTY(CCOD)
         cQUERY += " AND C6_PRODUTO = '"+ALLTRIM(CCOD)+"'"
      ENDIF
      IF !EMPTY(XTIPO)
         cQUERY += " AND B1_TIPO = '"+ALLTRIM(XTIPO)+"' " 
      ENDIF
      IF !EMPTY(XGRUPO)
         cQUERY += " AND B1_GRUPO = '"+ALLTRIM(XGRUPO)+"' " 
      ENDIF

      cQUERY += " UNION ALL "
      cQUERY += " SELECT C4_DATA AS DTINI, '' AS PAI , '' AS PC, (RTRIM(LTRIM(C4_DOC))+'-'+LTRIM(RTRIM(C4_PRODUTO))+'-'+LTRIM(RTRIM(B1_DESC))) AS NUMOP, 0 AS EQTDE, C4_QUANT AS SQTDE, C4_PRODUTO AS MATERIAL, "
      cQUERY += " 'P' AS STATOP, 'S' AS TIPO FROM "+RETSQLNAME("SC4")+", "+RETSQLNAME("SB1")
      cQUERY += " WHERE C4_QUANT > 0 AND "+RETSQLNAME("SC4")+".D_E_L_E_T_ <> '*' "  
      cQUERY += " AND "+RETSQLNAME("SB1")+".D_E_L_E_T_ <> '*' "
      cQUERY += " AND C4_PRODUTO = B1_COD "
      CQUERY += " AND B1_FILIAL = '"+XFILIAL("SB1")+"' AND C4_FILIAL = '"+XFILIAL("SC7")+"' "
      IF !EMPTY(CCOD)
         cQUERY += " AND C4_PRODUTO = '"+ALLTRIM(CCOD)+"'"
      ENDIF
      IF !EMPTY(XTIPO)
         cQUERY += " AND B1_TIPO = '"+ALLTRIM(XTIPO)+"' " 
      ENDIF
      IF !EMPTY(XGRUPO)
         cQUERY += " AND B1_GRUPO = '"+ALLTRIM(XGRUPO)+"' " 
      ENDIF
      
   ELSE  //PI

      cQUERY += " UNION ALL "
      cQUERY += " SELECT C2_DATPRI AS DTINI, C2_PRODUTO AS PAI , '' AS PC, (C2_TPOP+'-'+SUBSTRING(D4_OP,1,6)) AS NUMOP, 0 AS EQTDE, D4_QUANT AS SQTDE, D4_COD AS MATERIAL, " 
      cQUERY += " C2_TPOP AS STATOP, 'S' AS TIPO FROM "+RETSQLNAME("SD4")+", "+RETSQLNAME("SC2")+", "+RETSQLNAME("SB1")
      cQUERY += " WHERE D4_FILIAL = '"+XFILIAL("SD4")+"' AND "+RETSQLNAME("SD4")+".D_E_L_E_T_ <> '*' AND "
      cQUERY += RETSQLNAME("SC2")+".D_E_L_E_T_ <> '*' AND "+RETSQLNAME("SB1")+".D_E_L_E_T_ <> '*' "
      cQUERY += " AND B1_COD = D4_COD AND D4_OP = C2_NUM+C2_ITEM+C2_SEQUEN "
      CQUERY += " AND B1_FILIAL = '"+XFILIAL("SB1")+"' AND C2_FILIAL = '"+XFILIAL("SC2")+"'"
      IF !EMPTY(CCOD)
         cQUERY += " AND B1_COD = '"+ALLTRIM(CCOD)+"' " 
      ENDIF
      IF !EMPTY(XTIPO)
         cQUERY += " AND B1_TIPO = '"+ALLTRIM(XTIPO)+"' " 
      ENDIF
      cQUERY += " AND D4_QUANT > 0 "
      
   ENDIF
      
   cQUERY += " ORDER BY MATERIAL, DTINI, TIPO "
   cQUERY := ChangeQuery(cQUERY)
   dbUseArea(.T., "TOPCONN", TCGENQRY(,,CQUERY), "TRBSC2", .F., .T.)
   TCSetField( "TRBSC2", "DTINI", "D", 8, 0 )

ENDIF

IF EMPTY(CCOD)
  
  DBSELECTAREA("TRBSC2")
  DBGOTOP()
  DO WHILE !EOF()  

    XDOCSAIDA := ""
    XDOCENT   := ""  
    
    XMATERIA := TRBSC2->MATERIAL
    xESTATU  := 0
    
    DBSELECTAREA("SB2") 
    DBSETORDER(1)
    DBSEEK(XFILIAL("SB2")+XMATERIA)  
    
    DO WHILE !EOF() .AND. SB2->B2_FILIAL == XFILIAL("SB2") .AND. XMATERIA == SB2->B2_COD 
       IF ALLTRIM(SB2->B2_LOCAL) <> "NC"
	      xESTATU += SB2->B2_QATU
	   ENDIF
       DBSKIP()
    ENDDO      
    
    XSALDO := xESTATU
    
    DBSELECTAREA("TRBSC2")
    
    DO WHILE TRBSC2->MATERIAL == XMATERIA
    
       XSALDO := XSALDO +(TRBSC2->EQTDE - TRBSC2->SQTDE)
    
       IF ALLTRIM(TRBSC2->TIPO) == "S"   
          IF !EMPTY(TRBSC2->PAI)
             DBSELECTAREA("SB1")
             DBSETORDER(1)
             DBSEEK(XFILIAL("SB1")+TRBSC2->PAI)
             IF FOUND()
                XDOCSAIDA := ALLTRIM(TRBSC2->NUMOP)+" - "+ALLTRIM(SB1->B1_COD)+" - "+ALLTRIM(SB1->B1_DESC)+SPACE(10)
             ENDIF    
         ELSE 
           XDOCSAIDA := ALLTRIM(TRBSC2->NUMOP)
         ENDIF    
       ELSE
          XDOCENT   := TRBSC2->PC     
       ENDIF  
    
   	   IF LEN(RETSEM(TRBSC2->DTINI)) > 2
	      xRETSEM := STRZERO(VAL(alltrim(SUBSTR(RETSEM(TRBSC2->DTINI),8,2))),2)
	   ELSE
	      xRETSEM := STRZERO(VAL(RETSEM(TRBSC2->DTINI)),2)
	   ENDIF
	
       AAdd(aItens3,{TRBSC2->MATERIAL,TRBSC2->DTINI,;
	     XDOCENT,;
         TRANSFORM(TRBSC2->EQTDE,"@E 999,999,999.999"),;
         XDOCSAIDA,;
         TRANSFORM(TRBSC2->SQTDE,"@E 999,999,999.999"),;
	     TRANSFORM(XSALDO,"@E 999,999,999.999"),;
	     TRBSC2->STATOP,;
	   	 ALLTRIM(XRETSEM)+"/"+STRZERO(YEAR(TRBSC2->DTINI),4)})
    
       DBSELECTAREA("TRBSC2")
       DBSKIP() 
    
    Enddo
  
  Enddo
  
  IF LEN(aitens3) == 0
     
     AAdd(aItens3,{"",dDatabase,;
     "",;
     0,;
     "",;
     0,;
     0,;
     "",;
  	 ""})    
  	 
  ENDIF

  oLbx3:SetArray(aItens3)
  oLbx3:bLine:= {|| { aItens3[oLbx3:nAt,1],;
  aItens3[oLbx3:nAt,2],;
  aItens3[oLbx3:nAt,3],;
  aItens3[oLbx3:nAt,4],;  
  aItens3[oLbx3:nAt,5],;   
  aItens3[oLbx3:nAt,6],;
  aItens3[oLbx3:nAt,7],; 
  aItens3[oLbx3:nAt,8],; 
  aItens3[oLbx3:nAt,9]}}
  oLbx2:Hide()
  oLbx3:Show()
  oLbx3:Refresh()

ELSE

  DBSELECTAREA("TRBSC2")
  DBGOTOP()
  DO WHILE !EOF()  

    XDOCSAIDA := ""
    XDOCENT   := ""  

    XSALDO := XSALDO +(TRBSC2->EQTDE - TRBSC2->SQTDE)
    
    IF ALLTRIM(TRBSC2->TIPO) == "S"     
       IF !EMPTY(TRBSC2->PAI)
          DBSELECTAREA("SB1")
          DBSETORDER(1)
          DBSEEK(XFILIAL("SB1")+TRBSC2->PAI)
          IF FOUND()
             XDOCSAIDA := ALLTRIM(TRBSC2->NUMOP)+" - "+ALLTRIM(SB1->B1_COD)+" - "+ALLTRIM(SB1->B1_DESC)+SPACE(10)
          ENDIF 
       ELSE    
          XDOCSAIDA := ALLTRIM(TRBSC2->NUMOP)
       ENDIF
    ELSE
       XDOCENT   := TRBSC2->PC     
    ENDIF  
    
	IF LEN(RETSEM(TRBSC2->DTINI)) > 2
	   XRETSEM := STRZERO(VAL(alltrim(SUBSTR(RETSEM(TRBSC2->DTINI),8,2))),2)
	ELSE
	   XRETSEM := STRZERO(VAL(RETSEM(TRBSC2->DTINI)),2)
	ENDIF
	   	 	
    AAdd(aItens2,{TRBSC2->DTINI,;
	     XDOCENT,;
         TRANSFORM(TRBSC2->EQTDE,"@E 999,999,999.999"),;
         XDOCSAIDA,;
         TRANSFORM(TRBSC2->SQTDE,"@E 999,999,999.999"),;
	     TRANSFORM(XSALDO,"@E 999,999,999.999"),;
	     TRBSC2->STATOP,;
         ALLTRIM(XRETSEM)+"/"+STRZERO(YEAR(TRBSC2->DTINI),4)})
    
    DBSELECTAREA("TRBSC2")
    DBSKIP() 
    
  Enddo

  IF LEN(aitens2) == 0
     AAdd(aItens2,{dDatabase,;
	     "",;
         "0",;
         "",;
         "0",;
	     "0",;
	     "",;
	   	 ""})
  ENDIF
  
  oLbx2 := TCBrowse():New(035,010,610,250,,,,oDlg1,,,,,,,,,,,,.F.,,.T.,,.F.,,,)
  oLbx2:AddColumn(TCColumn():New("Data"   , {|| aItens2[oLbx2:nAt,01]},"",,,"CENTER", 010,.F.,.F.,,,,.F., ) ) 
  oLbx2:AddColumn(TCColumn():New("Doc Entrada" , {|| aItens2[oLbx2:nAt,02]},"@!",,,"LEFT", 040,.F.,.F.,,{|| .F. },,.F., ) )
  oLbx2:AddColumn(TCColumn():New("Qtde Entrada"   , {|| aItens2[oLbx2:nAt,03]},"@!",,,"RIGHT", 010,.F.,.F.,,,,.F., ) )
  oLbx2:AddColumn(TCColumn():New("Doc Saida", {|| aItens2[oLbx2:nAt,04]},"@!",,,"LEFT", 050,.F.,.F.,,,,.F., ) )
  oLbx2:AddColumn(TCColumn():New("Qtde Saida" , {|| aItens2[oLbx2:nAt,05]},"@!",,,"RIGHT", 040,.F.,.F.,,{|| .F. },,.F., ) )
  oLbx2:AddColumn(TCColumn():New("Saldo"   , {|| aItens2[oLbx2:nAt,06]},"@!",,,"RIGHT", 010,.F.,.F.,,,,.F., ) )
  oLbx2:AddColumn(TCColumn():New("Status", {|| aItens2[oLbx2:nAt,07]},"@!",,,"CENTER", 050,.F.,.F.,,,,.F., ) )      
  oLbx2:AddColumn(TCColumn():New("Semana", {|| aItens2[oLbx2:nAt,08]},"@!",,,"LEFT", 050,.F.,.F.,,,,.F., ) )      

  oLbx2:SetArray(aItens2)
  oLbx2:bWhen := { || Len(aItens2) > 0 }
  oLbx2:Show()
  oLbx2:SetBlkBackColor({|| IF(oLbx2:nAt>0,FGDCOR(),16777215)})    
  oLbx2:SetBlkColor({|| IF(oLbx2:nAt>0,IF( val(STRTRAN(STRTRAN(aItens2[oLbx2:nAt,06],".",""),",",".")) < 0,255,0),0)}) 
  oLbx3:Hide()
  oLbx2:Refresh()

ENDIF

DBSELECTAREA("TRBSC2")
DBCLOSEAREA("TRBSC2")

DBSELECTAREA("SB1")
GO XRECSB1

Return       

STATIC FUNCTION FGDCOR() 

IF aItens2[oLbx2:nAt,01] >= dDATAP .AND. LEN(oLbx2:aArray) == 1 
   RETURN RGB(238,221,130)
ENDIF

IF aItens2[oLbx2:nAt,01] == dDATAP  
   RETURN RGB(238,221,130)  
ELSE  
   IF aItens2[oLbx2:nAt,01] < dDATAP  
     IF oLbx2:nAt+1 <= LEN(oLbx2:aArray)
        IF aItens2[oLbx2:nAt+1,01] > dDATAP 
           RETURN RGB(238,221,130)
        ELSE
           RETURN 16777215    
        ENDIF   
     ELSE
        RETURN 16777215 
     ENDIF    
   ELSE
     RETURN 16777215   
   ENDIF  
ENDIF

RETURN 16777215 
